<?php
// api/get_orders.php

header('Content-Type: application/json');

// --- Includes ---
require_once '../includes/session.php';      // Start session and check login status
require_once '../includes/database.php';     // Provides $pdo
require_once '../includes/config.php';       // Potentially for settings
require_once '../includes/functions.php';    // Potential helper functions

// --- Helper Function for API Response ---
function send_json_response($data, $statusCode = 200) {
    http_response_code($statusCode);
    // Ensure numeric values are encoded correctly
    echo json_encode($data, JSON_PRESERVE_ZERO_FRACTION | JSON_UNESCAPED_SLASHES | JSON_NUMERIC_CHECK);
    exit;
}

// --- Authentication Check ---
if (!isUserLoggedIn()) { // Use function from functions.php
    send_json_response(['error' => 'Unauthorized access. Please login.'], 401);
}
$user_id = $_SESSION['user_id'];

// --- Fetch Order History from Database ---
try {
    // Prepare SQL query to select orders for the specific user
    // Order by timestamp descending to get the most recent orders first
    $sql = "SELECT
                id,
                timestamp,
                symbol,
                type,
                quantity,
                price,
                total,
                status
            FROM orders
            WHERE user_id = :user_id
            ORDER BY timestamp DESC";

    $stmt = $pdo->prepare($sql);

    // Bind the user ID parameter
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);

    // Execute the query
    $stmt->execute();

    // Fetch all matching orders as an associative array
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Optional: Format data if needed before sending
    // For example, ensure numeric types if not using JSON_NUMERIC_CHECK
    // foreach ($orders as &$order) {
    //     $order['quantity'] = (float)$order['quantity'];
    //     $order['price'] = (float)$order['price'];
    //     $order['total'] = (float)$order['total'];
    // }
    // unset($order); // Unset reference

    // --- Send Successful Response ---
    // Return the array of orders (will be an empty array [] if no orders found)
    send_json_response($orders, 200);

} catch (PDOException $e) {
    // --- Handle Database Errors ---
    error_log("Database error fetching order history for user $user_id: " . $e->getMessage());
    send_json_response(['error' => 'Failed to retrieve order history from database.'], 500); // Internal Server Error
} catch (Exception $e) {
    // --- Handle Other Potential Errors ---
     error_log("Error in api/get_orders.php for user $user_id: " . $e->getMessage());
     send_json_response(['error' => 'An unexpected error occurred while fetching order history.'], 500);
}

?>