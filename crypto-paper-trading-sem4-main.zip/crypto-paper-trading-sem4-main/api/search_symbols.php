<?php
// api/search_symbols.php

header('Content-Type: application/json');

// --- Includes ---
require_once '../includes/config.php';       // Potentially for API URLs/settings
require_once '../includes/functions.php';    // Potential helper functions
// IMPORTANT: Assumes fetchExchangeInfo() exists in binance_api.php
require_once '../includes/binance_api.php';

// --- Helper Function for API Response ---
function send_json_response($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data);
    exit;
}

// --- Input Parameters ---
// Optional search query
$search_query = isset($_GET['query']) ? strtoupper(trim($_GET['query'])) : '';
// Optional limit on number of results
$limit = isset($_GET['limit']) ? filter_var($_GET['limit'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) : 15; // Default limit 15
if ($limit === false) {
    $limit = 15; // Reset to default if invalid input
}


// --- Fetch Exchange Info from Binance ---
try {
    // This function (needs implementation in includes/binance_api.php)
    // should call https://api.binance.com/api/v3/exchangeInfo
    // and return the 'symbols' array part of the response.
    // It should handle cURL errors and basic response validation.
    $all_symbols_data = fetchExchangeInfo(); // Expected to return array of symbol objects

    if (!is_array($all_symbols_data)) {
         throw new Exception("Invalid data format received from fetchExchangeInfo.");
    }

} catch (Exception $e) {
    error_log("Failed to fetch or process Binance exchange info: " . $e->getMessage());
    send_json_response(['error' => 'Could not retrieve symbol list from the exchange.'], 502); // Bad Gateway
}


// --- Filter Symbols ---
$matching_symbols = [];
foreach ($all_symbols_data as $symbol_info) {
    // Basic checks: ensure it's an array/object with needed keys and status is TRADING
    if (!is_array($symbol_info) || !isset($symbol_info['symbol']) || !isset($symbol_info['status']) || $symbol_info['status'] !== 'TRADING') {
        continue; // Skip non-trading or malformed symbols
    }

    $current_symbol = $symbol_info['symbol']; // e.g., BTCUSDT

    // Apply search query filter if provided
    if (!empty($search_query)) {
        // Check if the symbol string contains the query (case-insensitive check already handled by uppercasing query)
        if (str_contains($current_symbol, $search_query) === false) {
            continue; // Skip if query doesn't match
        }
    }

    // Add relevant info to our results array
    $matching_symbols[] = [
        'symbol' => $current_symbol,
        'baseAsset' => $symbol_info['baseAsset'] ?? 'N/A',   // e.g., BTC
        'quoteAsset' => $symbol_info['quoteAsset'] ?? 'N/A', // e.g., USDT
        // Add other useful info if needed, e.g., precision rules:
        // 'baseAssetPrecision' => $symbol_info['baseAssetPrecision'] ?? null,
        // 'quoteAssetPrecision' => $symbol_info['quoteAssetPrecision'] ?? null,
        // 'filters' => $symbol_info['filters'] ?? [] // Contains price/lot size filters etc.
    ];

    // Optimization: If we have enough results already and don't need to sort extensively,
    // we could potentially stop early if only a limit is needed and no query was given.
    // However, filtering all first is usually cleaner.
}


// --- Optional: Sort Results (e.g., alphabetically) ---
// This makes the results consistent and predictable
usort($matching_symbols, function ($a, $b) {
    // Prioritize symbols starting with the query? Optional.
    // Simple alphabetical sort for now:
    return strcmp($a['symbol'], $b['symbol']);
});


// --- Apply Limit ---
$final_results = array_slice($matching_symbols, 0, $limit);


// --- Send Response ---
send_json_response($final_results, 200);

?>