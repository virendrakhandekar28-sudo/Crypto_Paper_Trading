<?php
// api/get_market_data.php

header('Content-Type: application/json');

// --- Includes ---
// Assuming binance_api.php can fetch multiple ticker data
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/binance_api.php'; // Needs a function to get multiple tickers

// --- Helper Function for API Response ---
function send_json_response($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data);
    exit;
}

// --- Fetch Data from Binance ---
// We need a function in binance_api.php to fetch data for multiple symbols,
// typically using the /api/v3/ticker/24hr endpoint without parameters,
// or /api/v3/ticker/price without parameters.
// Let's assume a function fetchTopMarketData() exists for this purpose.

try {
    // Option 1: Assume a function that gets multiple prices
    // $allPrices = fetchMultipleCryptoPrices(['BTCUSDT', 'ETHUSDT', 'BNBUSDT', ...]); // Less ideal for overview

    // Option 2: Assume a function that fetches 24hr ticker data (Better for overview)
    // This function needs to exist in includes/binance_api.php and call /api/v3/ticker/24hr
    if (!function_exists('fetch24hrTickerData')) {
         // Fallback/placeholder if function doesn't exist yet
         // You MUST implement fetch24hrTickerData in binance_api.php
         error_log("Error: fetch24hrTickerData() function not found in binance_api.php");
         throw new Exception("Server configuration error: Cannot fetch market data.");
         // $market_data = [ // Dummy data for testing UI
         //     ['symbol' => 'BTCUSDT', 'price' => '65000.00', 'priceChangePercent' => '1.5'],
         //     ['symbol' => 'ETHUSDT', 'price' => '3500.00', 'priceChangePercent' => '-0.5'],
         //     ['symbol' => 'BNBUSDT', 'price' => '600.00', 'priceChangePercent' => '3.2'],
         // ];
    } else {
         $market_data = fetch24hrTickerData(); // Fetch data for all pairs
    }

    // --- Process & Filter Data (Example) ---
    // The /ticker/24hr endpoint returns a LOT of data. We likely want to filter/sort it.
    // Let's filter for USDT pairs and sort by volume or market cap (if available)

    $usdt_pairs = [];
    if (is_array($market_data)) {
        foreach ($market_data as $ticker) {
            // Ensure necessary keys exist and filter (e.g., only USDT pairs)
            if (isset($ticker['symbol'], $ticker['lastPrice'], $ticker['priceChangePercent']) && str_ends_with($ticker['symbol'], 'USDT')) {

                 // Check if priceChangePercent is valid number, default to 0 if not
                 $changePercent = is_numeric($ticker['priceChangePercent']) ? (float)$ticker['priceChangePercent'] : 0.0;

                 $usdt_pairs[] = [
                    'symbol' => $ticker['symbol'],
                    'price' => $ticker['lastPrice'], // Use lastPrice from 24hr ticker
                    'priceChangePercent' => $changePercent,
                    // Add other relevant fields if needed (e.g., volume)
                    'volume' => $ticker['quoteVolume'] ?? '0' // 24hr volume in quote asset
                 ];
            }
        }

        // Sort by volume (descending) to show most active pairs first
         usort($usdt_pairs, function ($a, $b) {
            // Compare using quoteVolume (adjust field name if needed)
             return $b['volume'] <=> $a['volume'];
        });

    } else {
         throw new Exception("Invalid market data received from API helper.");
    }


    // Limit the results (e.g., top 20)
    $limited_results = array_slice($usdt_pairs, 0, 20); // Show top 20 by volume

    // --- Send Response ---
    // Send the filtered and sorted data back
    send_json_response($limited_results, 200);

} catch (Exception $e) {
    error_log("Error in api/get_market_data.php: " . $e->getMessage());
    send_json_response(['error' => 'Failed to retrieve market overview data. ' . $e->getMessage()], 500); // Internal Server Error or appropriate code
}

?>