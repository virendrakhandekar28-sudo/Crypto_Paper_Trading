<?php
// api/place_order.php
// Handles opening NEW Long/Short positions or CLOSING existing positions by ID.

header('Content-Type: application/json');

// --- Includes ---
require_once '../includes/session.php';      // Start session and get user_id
require_once '../includes/database.php';     // Provides $pdo
require_once '../includes/config.php';       // Potentially for settings
require_once '../includes/functions.php';    // Potential helper functions
require_once '../includes/binance_api.php'; // Needs fetchSingleCryptoPrice()

// --- Custom Exception Classes ---
class TradingLogicException extends Exception {}
class InsufficientFundsException extends TradingLogicException {}
class PositionNotFoundException extends TradingLogicException {}


// --- Helper Function for API Response ---
function send_json_response($data, $statusCode = 200) {
    http_response_code($statusCode);
    // Ensure numeric values are encoded correctly
    echo json_encode($data, JSON_PRESERVE_ZERO_FRACTION | JSON_UNESCAPED_SLASHES | JSON_NUMERIC_CHECK);
    exit;
}

// --- Authentication Check ---
if (!isUserLoggedIn()) {
    send_json_response(['error' => 'Unauthorized access. Please login.'], 401);
}
$user_id = $_SESSION['user_id'];

// --- Input Validation & Processing ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['error' => 'Invalid request method. Only POST allowed.'], 405);
}
$input_data = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE) {
    send_json_response(['error' => 'Invalid JSON data provided.'], 400);
}

// --- Determine Action: OPEN or CLOSE ---
// A request to CLOSE must include 'position_id'
$action_purpose = isset($input_data['position_id']) && !empty($input_data['position_id']) ? 'CLOSE' : 'OPEN';
$position_id_to_close = ($action_purpose === 'CLOSE') ? filter_var($input_data['position_id'], FILTER_VALIDATE_INT) : null;

// Validate required fields based on action
if ($action_purpose === 'OPEN') {
    $required_fields = ['symbol', 'type', 'quantity'];
    foreach ($required_fields as $field) {
        if (!isset($input_data[$field]) || ($input_data[$field] !== '0' && empty(trim((string)$input_data[$field])))) {
            send_json_response(['error' => "Missing or empty field for opening order: {$field}"], 400);
        }
    }
    // Get OPEN order details
    $trading_pair = strtoupper(trim($input_data['symbol']));
    $order_type = strtoupper(trim($input_data['type'])); // BUY for LONG, SELL for SHORT
    $quantity_str = trim((string)$input_data['quantity']);
    if (!is_numeric($quantity_str) || floatval($quantity_str) <= 0) send_json_response(['error' => 'Invalid quantity. Must be a positive number.'], 400);
    $quantity = floatval($quantity_str);

} elseif ($action_purpose === 'CLOSE') {
    if ($position_id_to_close === false || $position_id_to_close <= 0) {
        send_json_response(['error' => "Invalid position_id provided for closing order."], 400);
    }
    // For CLOSE, we fetch symbol, type (opposite), quantity from the position itself later
    $trading_pair = null; $order_type = null; $quantity = null; // Will be determined from position
} else {
    // Should not happen
    send_json_response(['error' => "Invalid action type derived."], 500);
}


// --- Validate Common Fields (Symbol format if OPENING) ---
if ($action_purpose === 'OPEN') {
    if ($order_type !== 'BUY' && $order_type !== 'SELL') send_json_response(['error' => 'Invalid order type. Must be BUY or SELL.'], 400);
    if (!preg_match('/^[A-Z0-9]{4,}$/', $trading_pair)) send_json_response(['error' => 'Invalid symbol format.'], 400);

    // Determine Base/Quote Asset (Simplistic)
    $base_asset = ''; $quote_asset = '';
    $common_quotes = ['USDT', 'BUSD', 'USDC', 'TUSD', 'DAI', 'BTC', 'ETH', 'BNB'];
    foreach ($common_quotes as $quote) { if (str_ends_with($trading_pair, $quote)) { $base_asset = substr($trading_pair, 0, -strlen($quote)); $quote_asset = $quote; break; } }
    if (empty($base_asset)) { if (strlen($trading_pair) > 3) { $base_asset = substr($trading_pair, 0, 3); $quote_asset = substr($trading_pair, 3); } else { send_json_response(['error' => "Could not determine base/quote asset for {$trading_pair}"], 400); } }
}
// For CLOSE, base_asset, quote_asset, trading_pair determined later from position data


// --- Start Database Transaction ---
$pdo->beginTransaction();
try {
    // 1. Get current cash balance (lock the row)
    $sql_get_cash = "SELECT cash_balance FROM portfolios WHERE user_id = :user_id FOR UPDATE";
    $stmt_get_cash = $pdo->prepare($sql_get_cash);
    $stmt_get_cash->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_get_cash->execute();
    $user_portfolio = $stmt_get_cash->fetch(PDO::FETCH_ASSOC);
    if (!$user_portfolio) throw new Exception("User portfolio not found.");
    $current_cash = floatval($user_portfolio['cash_balance']);

    // --- Declare variables needed in both branches ---
    $position_data = null; // Holds data of position being closed
    $current_price = 0.0;
    $order_value = 0.0;
    $new_cash_balance = $current_cash; // Start with current cash
    $realized_pnl = 0.0; // For closing orders


    // --- LOGIC BRANCH: CLOSE Existing Position ---
    if ($action_purpose === 'CLOSE') {
        // 2a. Fetch the specific position to close (lock it)
        $sql_get_pos = "SELECT id, symbol, trading_pair, direction, quantity, entry_price
                        FROM trade_positions
                        WHERE id = :pos_id AND user_id = :user_id AND status = 'OPEN' FOR UPDATE";
        $stmt_get_pos = $pdo->prepare($sql_get_pos);
        $stmt_get_pos->bindParam(':pos_id', $position_id_to_close, PDO::PARAM_INT);
        $stmt_get_pos->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_get_pos->execute();
        $position_data = $stmt_get_pos->fetch(PDO::FETCH_ASSOC);

        if (!$position_data) {
            throw new PositionNotFoundException("Open position with ID {$position_id_to_close} not found for this user.");
        }

        // Determine details for the closing order
        $trading_pair = $position_data['trading_pair']; // Get pair from position
        $base_asset = $position_data['symbol'];         // Get base asset from position
        $quantity = floatval($position_data['quantity']); // Quantity to close (always positive from DB)
        $order_type = ($position_data['direction'] === 'LONG') ? 'SELL' : 'BUY'; // Opposite action to close
        $entry_price = floatval($position_data['entry_price']);
        $original_direction = $position_data['direction'];

        // 3a. Fetch Current Price for closing
        $current_price_str = fetchSingleCryptoPrice($trading_pair);
        $current_price = floatval($current_price_str);
        if ($current_price <= 0) throw new Exception("Invalid market price for closing order.");
        $order_value = $quantity * $current_price; // Value of the closing order

        // 4a. Funds check (only if buying to close a short) & PnL Calculation
        if ($order_type === 'BUY') { // Buying to close SHORT
            if ($current_cash < $order_value) {
                 throw new InsufficientFundsException("Insufficient cash to buy back short position. Required: " . number_format($order_value, 2));
            }
            // Realized PnL for SHORT = (Entry Price - Exit Price) * Quantity
            $realized_pnl = ($entry_price - $current_price) * $quantity;
            // Cash increases by PnL + the initial margin freed (approximated by entry value)
            // Simplified: Cash change = Realized PnL
            // More accurate would need margin tracking. Here, just add PnL.
             $new_cash_balance = $current_cash + $realized_pnl;
             // The initial notional value used for margin check when opening is implicitly returned.
        } else { // Selling to close LONG
            // Realized PnL for LONG = (Exit Price - Entry Price) * Quantity
             $realized_pnl = ($current_price - $entry_price) * $quantity;
             // Cash increases by Sell Value (= Exit Price * Qty = order_value)
             // This inherently includes the PnL (order_value = entry_value + pnl)
             $new_cash_balance = $current_cash + $order_value;
        }

        // 5a. Update Position Status to CLOSED
        $sql_update_pos = "UPDATE trade_positions SET status = 'CLOSED' WHERE id = :pos_id";
        $stmt_update_pos = $pdo->prepare($sql_update_pos);
        $stmt_update_pos->bindParam(':pos_id', $position_id_to_close, PDO::PARAM_INT);
        if (!$stmt_update_pos->execute()) throw new Exception("Failed to close position status.");

        $success_message = "Position ID {$position_id_to_close} ({$original_direction} {$quantity} {$base_asset}) closed via {$order_type} order. Realized P/L: " . number_format($realized_pnl, 2);

    // --- LOGIC BRANCH: OPEN New Position ---
    } else { // OPEN action
        // 2b. Determine Direction from Order Type
        $direction = ($order_type === 'BUY') ? 'LONG' : 'SHORT';

        // 3b. Fetch Current Price for opening
        $current_price_str = fetchSingleCryptoPrice($trading_pair); // Already fetched if needed earlier
        $current_price = floatval($current_price_str);
        if ($current_price <= 0) throw new Exception("Invalid market price for opening order.");
        $order_value = $quantity * $current_price; // Value of the opening order

        // 4b. Funds/Margin Check
        if ($direction === 'LONG') {
            if ($current_cash < $order_value) {
                 throw new InsufficientFundsException("Insufficient cash to open LONG position. Required: " . number_format($order_value, 2));
            }
            $new_cash_balance = $current_cash - $order_value; // Deduct cash for long
        } else { // SHORT
            // Simplified 1x Notional Value Margin Check
            $margin_required = $order_value; // Notional value acts as margin needed
             if ($current_cash < $margin_required) {
                 throw new InsufficientFundsException("Insufficient cash margin to open SHORT position. Required: " . number_format($margin_required, 2));
             }
             // Cash balance does NOT decrease when opening short in this model (margin is just 'reserved')
             // $new_cash_balance remains $current_cash; it only changes when closing the short.
             // We could add a separate 'margin_used' field if desired. For now, keep it simple.
             $new_cash_balance = $current_cash;
        }

        // 5b. Insert New Position Row
        $sql_insert_pos = "INSERT INTO trade_positions (user_id, symbol, trading_pair, direction, quantity, entry_price, status)
                           VALUES (:uid, :sym, :pair, :dir, :qty, :entry, 'OPEN')";
        $stmt_insert_pos = $pdo->prepare($sql_insert_pos);

        // Use temp vars for bindParam
        $qty_param = number_format($quantity, 12, '.', '');
        $entry_param = number_format($current_price, 8, '.', '');

        $stmt_insert_pos->bindParam(':uid', $user_id, PDO::PARAM_INT);
        $stmt_insert_pos->bindParam(':sym', $base_asset, PDO::PARAM_STR);
        $stmt_insert_pos->bindParam(':pair', $trading_pair, PDO::PARAM_STR);
        $stmt_insert_pos->bindParam(':dir', $direction, PDO::PARAM_STR);
        $stmt_insert_pos->bindParam(':qty', $qty_param, PDO::PARAM_STR); // Quantity is always positive
        $stmt_insert_pos->bindParam(':entry', $entry_param, PDO::PARAM_STR);
        if (!$stmt_insert_pos->execute()) throw new Exception("Failed to open new position.");

         $success_message = ucfirst(strtolower($direction)) . " position opened via {$order_type} order for {$qty_param} {$base_asset} ({$trading_pair}) at approximately {$entry_param}.";
    }


    // --- Common Steps for Both OPEN and CLOSE ---

    // 6. Update Cash Balance in DB (if it changed)
    if (abs($new_cash_balance - $current_cash) > 1e-9) { // Check if cash actually changed
        $new_cash_balance_str = number_format($new_cash_balance, 8, '.', '');
        $sql_update_cash = "UPDATE portfolios SET cash_balance = :cash WHERE user_id = :user_id";
        $stmt_update_cash = $pdo->prepare($sql_update_cash);
        $stmt_update_cash->bindParam(':cash', $new_cash_balance_str, PDO::PARAM_STR);
        $stmt_update_cash->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        if (!$stmt_update_cash->execute()) throw new Exception("Failed to update cash balance.");
    } else {
        error_log("Cash balance unchanged for user $user_id after order type $order_type / action $action_purpose.");
    }

    // 7. Record Order in History
    $order_value_str = number_format($order_value, 8, '.', '');
    $quantity_str_order = number_format($quantity, 12, '.', ''); // Use positive quantity from position/input
    $current_price_str = number_format($current_price, 8, '.', '');

    $sql_insert_order = "INSERT INTO orders (user_id, position_id_closed, timestamp, symbol, type, quantity, price, total, status, order_purpose)
                         VALUES (:user_id, :pos_id, NOW(), :symbol, :type, :qty, :price, :total, 'FILLED', :purpose)";
    $stmt_insert_order = $pdo->prepare($sql_insert_order);
    $stmt_insert_order->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_insert_order->bindParam(':pos_id', $position_id_to_close, PDO::PARAM_INT); // Will be NULL for OPEN orders
    $stmt_insert_order->bindParam(':symbol', $trading_pair, PDO::PARAM_STR);
    $stmt_insert_order->bindParam(':type', $order_type, PDO::PARAM_STR); // BUY or SELL
    $stmt_insert_order->bindParam(':qty', $quantity_str_order, PDO::PARAM_STR);
    $stmt_insert_order->bindParam(':price', $current_price_str, PDO::PARAM_STR);
    $stmt_insert_order->bindParam(':total', $order_value_str, PDO::PARAM_STR);
    $stmt_insert_order->bindParam(':purpose', $action_purpose, PDO::PARAM_STR); // 'OPEN' or 'CLOSE'
    if (!$stmt_insert_order->execute()) throw new Exception("Failed to record order in history.");

    // --- Commit Transaction ---
    $pdo->commit();
    send_json_response(['success' => true, 'message' => $success_message ], 200);

} catch (Exception $e) {
    // --- Rollback and Send Error Response ---
    $pdo->rollBack();
    // Log detailed error
    $log_context = "[User: $user_id, Action: $action_purpose" .
                   ($action_purpose === 'OPEN' ? ", Pair: $trading_pair, Type: $order_type, Qty: $quantity" : ", PosID: $position_id_to_close") .
                   "]";
    error_log("Order placement failed $log_context: " . $e->getMessage() . "\n" . $e->getTraceAsString());

    // Send appropriate error response
    if ($e instanceof InsufficientFundsException || $e instanceof PositionNotFoundException) {
        send_json_response(['error' => $e->getMessage()], 400); // Bad request (user state error)
    } else {
        send_json_response(['error' => 'Order placement failed due to a server error.'], 500);
    }
}
?>