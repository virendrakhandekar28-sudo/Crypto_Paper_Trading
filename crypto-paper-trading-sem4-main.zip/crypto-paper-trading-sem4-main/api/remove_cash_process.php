<?php
// api/remove_cash_process.php

header('Content-Type: application/json');

// --- Includes ---
require_once '../includes/session.php';
require_once '../includes/database.php';
require_once '../includes/config.php';
require_once '../includes/functions.php';

// --- Custom Exception Class ---
class InsufficientFundsException extends Exception {}

// --- Helper Function for API Response ---
function send_json_response($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data, JSON_PRESERVE_ZERO_FRACTION | JSON_NUMERIC_CHECK);
    exit;
}

// --- Authentication Check ---
if (!isUserLoggedIn()) {
    send_json_response(['error' => 'Unauthorized. Please login.'], 401);
}
$user_id = $_SESSION['user_id'];

// --- Input Validation ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['error' => 'Invalid request method.'], 405);
}
$input_data = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE) {
    send_json_response(['error' => 'Invalid JSON data provided.'], 400);
}

if (!isset($input_data['amount']) || !is_numeric($input_data['amount']) || floatval($input_data['amount']) <= 0) {
    send_json_response(['error' => 'Invalid amount provided. Must be a positive number.'], 400);
}
$amount_to_remove = floatval($input_data['amount']);

// --- Database Update ---
$pdo->beginTransaction();
try {
    // Get current balance and lock row
    $sql_get = "SELECT cash_balance FROM portfolios WHERE user_id = :user_id FOR UPDATE";
    $stmt_get = $pdo->prepare($sql_get);
    $stmt_get->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_get->execute();
    $portfolio = $stmt_get->fetch(PDO::FETCH_ASSOC);

    if (!$portfolio) {
        throw new Exception("User portfolio record not found.");
    }
    $current_balance = floatval($portfolio['cash_balance']);

    // *** Check if sufficient funds to remove ***
    if ($current_balance < $amount_to_remove) {
        throw new InsufficientFundsException('Insufficient cash balance to remove requested amount. Available: ' . number_format($current_balance, 2));
    }

    // Calculate new balance
    $new_balance = $current_balance - $amount_to_remove;

    // Ensure balance doesn't go below zero due to floating point issues (optional safety)
    if ($new_balance < 0) {
         $new_balance = 0.0;
         error_log("Warning: Cash removal for user $user_id resulted in slightly negative balance, reset to 0.");
    }

    // Update balance
    $sql_update = "UPDATE portfolios SET cash_balance = :new_balance WHERE user_id = :user_id";
    $stmt_update = $pdo->prepare($sql_update);

    // Bind using formatted string for precision
    $new_balance_str = number_format($new_balance, 8, '.', '');
    $stmt_update->bindParam(':new_balance', $new_balance_str, PDO::PARAM_STR);
    $stmt_update->bindParam(':user_id', $user_id, PDO::PARAM_INT);

    if (!$stmt_update->execute()) {
        throw new Exception("Database update failed.");
    }

    // Commit transaction
    $pdo->commit();

    // Success response - include the new balance
    send_json_response([
        'success' => true,
        'message' => 'Removed ' . number_format($amount_to_remove, 2) . ' virtual cash.',
        'newBalance' => $new_balance // Send numeric new balance
    ], 200);

} catch (InsufficientFundsException $e) {
    // Specific error for insufficient funds - return 400 Bad Request
    $pdo->rollBack();
    send_json_response(['error' => $e->getMessage()], 400);
} catch (Exception $e) {
    // Generic server error
    $pdo->rollBack();
    error_log("Failed to remove cash for user $user_id: " . $e->getMessage());
    send_json_response(['error' => 'Could not remove cash due to a server error.'], 500);
}