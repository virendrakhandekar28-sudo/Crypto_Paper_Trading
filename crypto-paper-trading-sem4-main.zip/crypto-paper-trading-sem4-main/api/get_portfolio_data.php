<?php
// api/get_portfolio_data.php
// Fetches portfolio data based on individual OPEN long/short positions.

header('Content-Type: application/json');

// --- Includes ---
require_once '../includes/session.php';      // Start session and check login status
require_once '../includes/database.php';     // Provides $pdo
require_once '../includes/config.php';       // Potentially for settings
require_once '../includes/functions.php';    // Potential helper functions
require_once '../includes/binance_api.php'; // Needs fetchMultipleCryptoPrices()

// --- Helper Function for API Response ---
function send_json_response($data, $statusCode = 200) {
    http_response_code($statusCode);
    // Ensure numeric values are encoded correctly
    echo json_encode($data, JSON_PRESERVE_ZERO_FRACTION | JSON_UNESCAPED_SLASHES | JSON_NUMERIC_CHECK);
    exit;
}

// --- Authentication Check ---
if (!isUserLoggedIn()) {
    send_json_response(['error' => 'Unauthorized access. Please login.'], 401);
}
$user_id = $_SESSION['user_id'];

// --- Determine Request Type (Summary or Full) ---
// Summary view might need more specific logic later (e.g., separate long/short value)
$is_summary_request = isset($_GET['summary']) && filter_var($_GET['summary'], FILTER_VALIDATE_BOOLEAN);

// --- Data Initialization ---
$portfolio_data = [
    'cashBalance' => 0.00,
    'totalValue' => 0.00,         // Represents Total Portfolio Equity
    'cryptoValue' => 0.00,        // Represents Net Crypto Equity (Long Value - Short Liability)
    'holdings' => [],             // For full view - will contain individual positions
    'topHoldings' => []           // For summary view
];
$symbols_to_fetch = [];           // Stores base symbols (e.g., BTC)
$trading_pairs_to_fetch = [];     // Stores trading pairs (e.g., BTCUSDT)
$db_positions = [];               // Store fetched open positions

// --- Database Operations ---
try {
    // 1. Fetch Cash Balance
    $sql_cash = "SELECT cash_balance FROM portfolios WHERE user_id = :user_id LIMIT 1";
    $stmt_cash = $pdo->prepare($sql_cash);
    $stmt_cash->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_cash->execute();
    $cash_result = $stmt_cash->fetch(PDO::FETCH_ASSOC);
    $portfolio_data['cashBalance'] = $cash_result ? floatval($cash_result['cash_balance']) : 0.00;

    // Initialize total equity with cash balance
    $portfolio_data['totalValue'] = $portfolio_data['cashBalance'];

    // 2. Fetch All OPEN Asset Positions from the new 'trade_positions' table
    $sql_assets = "SELECT id, symbol, trading_pair, direction, quantity, entry_price
                   FROM trade_positions
                   WHERE user_id = :user_id AND status = 'OPEN'"; // Fetch OPEN positions only
    $stmt_assets = $pdo->prepare($sql_assets);
    $stmt_assets->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_assets->execute();
    $db_positions = $stmt_assets->fetchAll(PDO::FETCH_ASSOC);

    // Collect unique trading pairs needed for price fetching
    foreach ($db_positions as $position) {
        if (!empty($position['trading_pair']) && !in_array($position['trading_pair'], $trading_pairs_to_fetch)) {
             $trading_pairs_to_fetch[] = $position['trading_pair'];
        }
        // Store base symbol if needed for summary grouping later?
        // $symbols_to_fetch[$position['symbol']] = true;
    }

} catch (PDOException $e) {
    error_log("Database error fetching portfolio for user $user_id: " . $e->getMessage());
    send_json_response(['error' => 'Failed to retrieve portfolio data from database.'], 500);
}

// --- Fetch Live Prices ---
$live_prices = []; // Stores 'TRADINGPAIR' => price
if (!empty($trading_pairs_to_fetch)) {
    if (!function_exists('fetchMultipleCryptoPrices')) {
        error_log("Error: fetchMultipleCryptoPrices() function not found in binance_api.php");
        send_json_response(['error' => 'Server configuration error retrieving prices.'], 500);
    }
    try {
        // Fetch prices for all unique pairs needed by the open positions
        $live_prices = fetchMultipleCryptoPrices($trading_pairs_to_fetch);
    } catch (Exception $e) {
        error_log("Failed to fetch live prices for portfolio calculation user $user_id: " . $e->getMessage());
        // Proceeding without live prices - P/L and equity will be inaccurate
    }
}

// --- Calculate Position Values and P/L ---
$calculated_positions = [];
$total_crypto_equity = 0.00; // Net equity from crypto positions
$epsilon = 1e-12; // Small value for float comparison

foreach ($db_positions as $position) {
    $position_id = $position['id'];
    $symbol = $position['symbol']; // Base symbol (e.g., BTC)
    $trading_pair = $position['trading_pair']; // Pair used (e.g., BTCUSDT)
    $direction = $position['direction']; // 'LONG' or 'SHORT'
    $quantity = floatval($position['quantity']); // Always positive quantity
    $entry_price = floatval($position['entry_price']);

    $current_price = 0.00;
    if (isset($live_prices[$trading_pair])) {
        $current_price = floatval($live_prices[$trading_pair]);
    } else {
         error_log("Missing live price for position ID $position_id (Pair: $trading_pair) during portfolio calculation for user $user_id.");
         // If no current price, P/L calculation might be inaccurate or zero
    }

    // Calculate Current Notional Value (always positive magnitude)
    $current_notional_value = $quantity * $current_price;

    // Calculate Unrealized Profit/Loss
    $unrealized_pnl = 0.0;
    $unrealized_pnl_percent = 0.0;
    $entry_notional_value = $quantity * $entry_price;

    if ($entry_price > $epsilon) { // Calculate P/L only if entry price is valid
        if ($direction === 'LONG') {
            // PnL = (Current Value - Entry Value)
            $unrealized_pnl = $current_notional_value - $entry_notional_value;
             if ($entry_notional_value > $epsilon) {
                $unrealized_pnl_percent = ($unrealized_pnl / $entry_notional_value) * 100;
            }
        } else { // SHORT
            // PnL = (Entry Value - Current Value)
            $unrealized_pnl = $entry_notional_value - $current_notional_value;
             if ($entry_notional_value > $epsilon) {
                $unrealized_pnl_percent = ($unrealized_pnl / $entry_notional_value) * 100;
            }
        }
    }

    // Calculate the equity contribution of this position
    // Long positions contribute their current notional value.
    // Short positions contribute the negative of their current notional value (liability).
    $position_equity = ($direction === 'LONG') ? $current_notional_value : -$current_notional_value;
    $total_crypto_equity += $position_equity;


    // Store detailed position data for the 'holdings' array
    $calculated_positions[] = [
        'positionId' => $position_id, // Include position ID for closing actions
        'symbol' => $symbol,
        'tradingPair' => $trading_pair,
        'direction' => $direction, // LONG or SHORT
        'quantity' => $quantity, // Store the positive quantity
        'entryPrice' => $entry_price,
        'currentPrice' => $current_price,
        'currentValue' => $current_notional_value, // Notional Value (Magnitude)
        'profitLoss' => $unrealized_pnl,
        'profitLossPercent' => round($unrealized_pnl_percent, 2)
    ];
}

// Update overall portfolio figures
$portfolio_data['cryptoValue'] = $total_crypto_equity; // Net equity from crypto
$portfolio_data['totalValue'] = $portfolio_data['cashBalance'] + $total_crypto_equity; // Total Equity = Cash + Crypto Equity

// --- Structure Response (Full or Summary) ---
if ($is_summary_request) {
    // Summary: Sort by absolute notional value, return simplified info
    usort($calculated_positions, function ($a, $b) {
        // Sort descending by absolute current (notional) value
        return abs($b['currentValue']) <=> abs($a['currentValue']);
    });

    $top_holdings_count = 5; // Show top 5 positions
    $portfolio_data['topHoldings'] = array_slice($calculated_positions, 0, $top_holdings_count);
    // Simplify structure for summary
    $portfolio_data['topHoldings'] = array_map(function($p) {
        return [
            'symbol' => $p['symbol'],
            'direction' => $p['direction'],
            'quantity' => $p['quantity'], // Positive quantity
            'value' => $p['currentValue'] // Notional value
        ];
    }, $portfolio_data['topHoldings']);

    unset($portfolio_data['holdings']); // Remove full holdings for summary

} else {
    // Full view: Use the detailed calculated positions array
    // Sort alphabetically for consistent display in full view? Optional.
     usort($calculated_positions, function($a, $b) {
        return strcmp($a['symbol'], $b['symbol']) ?: strcmp($a['direction'], $b['direction']); // Sort by symbol then direction
     });

    $portfolio_data['holdings'] = $calculated_positions; // Key remains 'holdings' for frontend
    unset($portfolio_data['topHoldings']);
}

// --- Send Response ---
send_json_response($portfolio_data, 200);

?>