<?php
// api/get_live_prices.php

// Set the content type to JSON
header('Content-Type: application/json');

// --- Configuration ---
// Base URL for the relevant Binance API endpoint
define('BINANCE_API_PRICE_URL', 'https://api.binance.com/api/v3/ticker/price');
// Timeout for the cURL request in seconds
define('API_TIMEOUT', 0.5);

// --- Helper Function for API Response ---
function send_json_response($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data);
    exit; // Terminate script after sending response
}

// --- Input Validation ---
// Check if the 'symbol' GET parameter is provided
if (!isset($_GET['symbol']) || empty(trim($_GET['symbol']))) {
    send_json_response(['error' => 'Symbol parameter is required.'], 400); // Bad Request
}

// Sanitize and prepare the symbol (e.g., ensure uppercase)
$symbol = strtoupper(trim($_GET['symbol']));

// Optional: Basic validation for symbol format (e.g., letters only, certain length)
// Adjust regex as needed for valid Binance symbols (often base+quote like BTCUSDT)
if (!preg_match('/^[A-Z0-9]{4,}$/', $symbol)) {
     send_json_response(['error' => 'Invalid symbol format provided.'], 400); // Bad Request
}


// --- Fetch Data from Binance API ---
$apiUrl = BINANCE_API_PRICE_URL . '?symbol=' . urlencode($symbol);

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // Return the transfer as a string
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, API_TIMEOUT); // Connection timeout
curl_setopt($ch, CURLOPT_TIMEOUT, API_TIMEOUT); // Total request timeout
// Optional: Add headers if needed by the API (usually not for public price ticker)
// curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
// Optional: Set User-Agent (some APIs might require it)
// curl_setopt($ch, CURLOPT_USERAGENT, 'YourAppName/1.0');

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErrorNum = curl_errno($ch);
$curlError = curl_error($ch);

curl_close($ch);

// --- Handle cURL Errors ---
if ($curlErrorNum > 0) {
    error_log("cURL Error fetching Binance price for $symbol: #" . $curlErrorNum . " - " . $curlError);
    // Use 502 Bad Gateway as we failed to get data from the upstream server
    send_json_response(['error' => 'Failed to fetch data from external API.'], 502);
}

// --- Process Binance Response ---
if ($response === false || $response === '') {
     send_json_response(['error' => 'Empty response from external API.'], 502);
}

// Decode the JSON response from Binance
$data = json_decode($response, true); // true for associative array

// Check for JSON decoding errors
if (json_last_error() !== JSON_ERROR_NONE) {
    error_log("JSON Decode Error processing Binance response for $symbol: " . json_last_error_msg());
    send_json_response(['error' => 'Failed to process external API response.'], 500); // Internal Server Error
}

// Check for error messages returned within the Binance JSON payload
// Binance error format: {"code":-1121,"msg":"Invalid symbol."}
if (isset($data['code']) && isset($data['msg'])) {
    // Log the specific Binance error
    error_log("Binance API Error for $symbol: Code {$data['code']} - {$data['msg']}");
    // Send a user-friendly error - 404 Not Found is reasonable if symbol is invalid
    send_json_response(['error' => "Could not find price data for symbol '{$symbol}'. Message: {$data['msg']}"], 404);
}

// Check if the expected 'price' key exists
if (!isset($data['price']) || !isset($data['symbol'])) {
     error_log("Unexpected Binance response format for $symbol: " . $response);
     send_json_response(['error' => 'Unexpected data format from external API.'], 500);
}

// --- Success ---
// Return the data in the format expected by script.js
send_json_response([
    'symbol' => $data['symbol'], // Use the symbol returned by Binance for consistency
    'price' => $data['price']    // Return price as string (as Binance provides it) for precision
], 200); // OK

?>