/**
 * script.js
 *
 * Client-side scripting for Crypto Paper Trader
 * (Supports Separate Long/Short Positions Model).
 */

// --- Global Variables ---
let priceWebSocket = null; // Holds the WebSocket object for real-time prices
let currentSymbolForWebSocket = null; // Track symbol for WebSocket connection
let currentPrice = 0; // Store latest price globally for calculations on trade page

// --- Helper Functions ---

/**
 * Formats currency values.
 */
function formatCurrency(amount, currency = 'USD') {
    if (typeof amount !== 'number') amount = parseFloat(amount) || 0;
    return new Intl.NumberFormat('en-US', {
        style: 'currency', currency: currency,
        minimumFractionDigits: 2, maximumFractionDigits: 2 // Adjust if quote is crypto
    }).format(amount);
}

/**
 * Formats crypto quantities (always shows positive value).
 * Use CSS/context to indicate short positions.
 */
function formatCrypto(amount, maxDecimals = 8) {
     if (typeof amount !== 'number') amount = parseFloat(amount) || 0;
     const factor = Math.pow(10, maxDecimals);
     const roundedAmount = Math.floor(Math.abs(amount) * factor) / factor; // Format absolute value
     return roundedAmount.toFixed(maxDecimals).replace(/\.?0+$/, "");
}

/**
 * Helper function to make API calls using fetch.
 */
async function apiCall(url, options = {}) {
    try {
        const response = await fetch(url, {
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', ...options.headers, },
            ...options
        });
        if (!response.ok) {
            let errorData = {}; let specificMessage = response.statusText;
            try {
                 errorData = await response.json();
                 specificMessage = errorData.error || errorData.message || specificMessage;
            } catch (e) { /* Ignore if response body is not JSON */ }
            console.error(`API Error ${response.status}: ${response.statusText}`, errorData);
            throw new Error(`HTTP error ${response.status}: ${specificMessage}`);
        }
        const contentType = response.headers.get("content-type");
        if (response.status === 204 || !contentType || !contentType.includes("application/json")) { return {}; }
        return await response.json();
    } catch (error) { console.error('API Call Failed:', error); throw error; }
}


// --- Data Loading Functions ---

/**
 * Loads and displays the market overview data.
 */
async function loadMarketOverview(targetElementId) {
    const targetElement = document.getElementById(targetElementId);
    if (!targetElement) return;
    targetElement.innerHTML = '<p class="loading">Loading market data...</p>';
    try {
        const data = await apiCall('api/get_market_data.php');
        if (data && data.length > 0) {
            let html = '<h4>Top Movers (by Volume)</h4><ul id="market-list">';
            data.slice(0, 7).forEach(coin => {
                const price = parseFloat(coin.price) || 0;
                const change = parseFloat(coin.priceChangePercent) || 0;
                const changeClass = change >= 0 ? 'positive' : 'negative';
                html += `<li><strong>${coin.symbol}:</strong> ${formatCurrency(price)} <span class="${changeClass}">(${change.toFixed(2)}%)</span></li>`;
            });
            html += '</ul>'; targetElement.innerHTML = html;
        } else { targetElement.innerHTML = '<p>Could not load market data.</p>'; }
    } catch (error) {
        targetElement.innerHTML = '<p>Error loading market data. Please try again later.</p>';
        console.error("Error in loadMarketOverview:", error);
    }
}

/**
 * Loads and displays the portfolio summary (for Dashboard).
 */
async function loadPortfolioSummary(targetContentElementId) {
    const contentTargetElement = document.getElementById(targetContentElementId);
    if (!contentTargetElement) { console.error(`Portfolio Summary content target element #${targetContentElementId} not found!`); return; }
    contentTargetElement.innerHTML = '<p class="loading">Loading portfolio summary...</p>';
    console.log(`[Portfolio Summary] Attempting load for #${targetContentElementId}`);
    try {
        // API call uses ?summary=true
        const data = await apiCall('api/get_portfolio_data.php?summary=true');
        console.log("[Portfolio Summary] API call successful. Data:", data);
        if (data && typeof data === 'object') {
             console.log("[Portfolio Summary] Processing data...");
             // Use Equity terms matching the full portfolio page
             let html = `<p>Total Portfolio Equity: <strong>${formatCurrency(data.totalValue || 0)}</strong></p>`;
             html += `<p>Cash Balance: <strong>${formatCurrency(data.cashBalance || 0)}</strong></p>`;

             if (data.topHoldings && data.topHoldings.length > 0) {
                 html += '<h4>Largest Positions (by Value):</h4><ul id="top-holdings-list">';
                 data.topHoldings.forEach(holding => {
                      const direction = holding.direction || (holding.quantity >= 0 ? 'LONG' : 'SHORT'); // Infer if needed
                      const displayQty = formatCrypto(holding.quantity); // Positive quantity
                      const directionIndicator = direction === 'SHORT' ? '(Short)' : ''; // Indicator
                      // Display notional value
                      html += `<li><strong>${holding.symbol}:</strong> ${displayQty} ${directionIndicator} (${formatCurrency(holding.value || 0)})</li>`;
                 });
                 html += '</ul>';
             } else {
                 console.log("[Portfolio Summary] No holdings found.");
                 html += '<p>No open positions or holdings.</p>';
             }
             console.log("[Portfolio Summary] Generated HTML:", html);
             if (contentTargetElement) {
                contentTargetElement.innerHTML = html;
                console.log("[Portfolio Summary] Successfully updated innerHTML for #" + targetContentElementId);
             } else { console.error("[Portfolio Summary] ERROR: Content target element became invalid!"); }
         } else {
             console.warn("[Portfolio Summary] Data received but was not a valid object:", data);
             if (contentTargetElement) contentTargetElement.innerHTML = '<p>Could not load portfolio summary (Invalid data format).</p>';
         }
    } catch (error) {
         console.error("[Portfolio Summary] ERROR caught in loadPortfolioSummary:", error);
         const errorTargetElement = document.getElementById(targetContentElementId);
         if (errorTargetElement) { errorTargetElement.innerHTML = '<p>Error loading portfolio summary: ' + error.message + '</p>'; }
         else { console.error("[Portfolio Summary] ERROR: Content target element is undefined inside CATCH!"); }
    }
}


/**
 * Loads the full portfolio details (for portfolio.php).
 * Renders individual LONG/SHORT positions from the 'holdings' array (which contains positions).
 */
async function loadFullPortfolio(targetTableBodyId) {
    const targetElement = document.getElementById(targetTableBodyId);
     if (!targetElement) { console.error(`Full Portfolio target element #${targetTableBodyId} not found!`); return; }

    const cashBalanceEl = document.getElementById('portfolio-cash-balance');
    const cryptoValueEl = document.getElementById('portfolio-crypto-value'); // Net Crypto Equity
    const totalValueEl = document.getElementById('portfolio-total-value'); // Total Equity
    const messageDiv = document.getElementById('portfolio-action-message');

    if(messageDiv) { messageDiv.textContent = ''; messageDiv.className='portfolio-action-message'; }
    // Colspan is 7 (Symbol, Position, Entry, Current, Notional, P/L, Action)
    targetElement.innerHTML = `<tr><td colspan="7" class="loading-placeholder">Loading portfolio details...</td></tr>`;
    if (cashBalanceEl) cashBalanceEl.innerHTML = '<span class="loading">Loading...</span>';
    if (cryptoValueEl) cryptoValueEl.innerHTML = '<span class="loading">Loading...</span>';
    if (totalValueEl) totalValueEl.innerHTML = '<span class="loading">Loading...</span>';

    console.log(`[Portfolio Full] Attempting load for #${targetTableBodyId}`);
    try {
        const data = await apiCall('api/get_portfolio_data.php'); // No summary flag
        console.log("[Portfolio Full] API call successful. Data:", data);

        let totalCryptoEquity = 0; // Calculated client-side based on API data

        if (cashBalanceEl) { cashBalanceEl.textContent = formatCurrency(data.cashBalance || 0); }

        if (data.holdings && data.holdings.length > 0) { // 'holdings' array now contains position objects
            let tableRowsHtml = '';
            data.holdings.forEach(p => { // 'p' for position object
                const quantity = parseFloat(p.quantity) || 0; // Positive quantity of the position
                const direction = p.direction || 'UNKNOWN'; // 'LONG' or 'SHORT'
                const avgEntryPrice = parseFloat(p.entryPrice) || 0;
                const currentPrice = parseFloat(p.currentPrice) || 0;
                const currentValue = parseFloat(p.currentValue) || 0; // Notional Value (magnitude)
                const profitLoss = parseFloat(p.profitLoss) || 0;
                const profitLossPercent = parseFloat(p.profitLossPercent) || 0;
                const plClass = profitLoss >= 0 ? 'positive' : 'negative';
                const tradingPair = p.tradingPair || `${p.symbol}USDT`;
                const positionId = p.positionId; // ** Crucial: Get Position ID **

                let actionButtonHtml = '';
                let positionDisplay = '';

                if (direction === 'LONG') {
                    positionDisplay = `${formatCrypto(quantity)} (Long)`;
                    actionButtonHtml = `<button class="action-position-btn exit-long" data-position-id="${positionId}" data-symbol="${p.symbol}" data-quantity="${quantity}" data-pair="${tradingPair}" data-direction="${direction}">Sell to Close</button>`;
                } else if (direction === 'SHORT') {
                     positionDisplay = `${formatCrypto(quantity)} (Short)`; // Indicate short
                     actionButtonHtml = `<button class="action-position-btn exit-short" data-position-id="${positionId}" data-symbol="${p.symbol}" data-quantity="${quantity}" data-pair="${tradingPair}" data-direction="${direction}">Buy to Close</button>`;
                } else {
                     positionDisplay = `${formatCrypto(quantity)} (?)`; // Unknown direction
                }


                 tableRowsHtml += `
                    <tr>
                        <td>${p.symbol}</td>
                        <td>${positionDisplay}</td>
                        <td>${formatCurrency(avgEntryPrice)}</td>
                        <td>${formatCurrency(currentPrice)}</td>
                        <td>${formatCurrency(currentValue)}</td> <!-- Notional Value -->
                        <td class="${plClass}">${formatCurrency(profitLoss)} (${profitLossPercent.toFixed(2)}%)</td>
                        <td>${actionButtonHtml}</td>
                    </tr>
                `;
                // Recalculate equity contribution client-side for consistency
                totalCryptoEquity += (direction === 'LONG' ? currentValue : -currentValue);
            });
            targetElement.innerHTML = tableRowsHtml;
             console.log("[Portfolio Full] Table updated.");
        } else {
            targetElement.innerHTML = `<tr><td colspan="7" class="no-holdings-placeholder">You have no open positions.</td></tr>`; // Colspan 7
             console.log("[Portfolio Full] No open positions found.");
        }

        // Update summary (using client-side calculated equity for consistency)
         if (cryptoValueEl) { cryptoValueEl.textContent = formatCurrency(totalCryptoEquity); }
         if (totalValueEl) {
             // Use totalValue from API if available, otherwise calculate
             const finalTotalValue = (typeof data.totalValue !== 'undefined') ? data.totalValue : ((data.cashBalance || 0) + totalCryptoEquity);
             totalValueEl.textContent = formatCurrency(finalTotalValue);
         }
          console.log("[Portfolio Full] Summary updated.");

    } catch (error) {
        console.error("[Portfolio Full] ERROR caught in loadFullPortfolio:", error);
        targetElement.innerHTML = `<tr><td colspan="7" class="error-placeholder">Error loading portfolio details: ${error.message}</td></tr>`; // Colspan 7
         if (cashBalanceEl) cashBalanceEl.textContent = 'Error';
         if (cryptoValueEl) cryptoValueEl.textContent = 'Error';
         if (totalValueEl) totalValueEl.textContent = 'Error';
    }
}


/**
 * Loads the user's order history.
 */
async function loadOrderHistory(targetElementId) {
     const targetElement = document.getElementById(targetElementId);
     if (!targetElement) return;
     // Ensure colspan matches table headers (Date, Type, Symbol, Qty, Price, Total, Status, Purpose?) - Adjust if needed
     const orderTableColspan = 8; // If 'Purpose' column added to orders table display
     targetElement.innerHTML = `<tr><td colspan="${orderTableColspan}">Loading order history...</td></tr>`;
     try {
         const orders = await apiCall('api/get_orders.php');
         if (orders && orders.length > 0) {
             let tableRowsHtml = '';
             orders.forEach(order => {
                 const orderTypeClass = order.type.toUpperCase() === 'BUY' ? 'positive' : 'negative';
                 // Display purpose if available
                 const purposeText = order.order_purpose ? `(${order.order_purpose})` : '';
                 tableRowsHtml += `
                    <tr>
                        <td>${new Date(order.timestamp).toLocaleString()}</td>
                        <td class="${orderTypeClass}">${order.type.toUpperCase()} ${purposeText}</td>
                        <td>${order.symbol}</td>
                        <td>${formatCrypto(order.quantity)}</td>
                        <td>${formatCurrency(order.price)}</td>
                        <td>${formatCurrency(order.total)}</td>
                        <td>${order.status}</td>
                        <td>${order.position_id_closed || '-'}</td> <!-- Show closed position ID -->
                    </tr>`;
                     // Adjust headers in orders.php if adding Purpose/Closed ID columns
             });
             targetElement.innerHTML = tableRowsHtml;
         } else { targetElement.innerHTML = `<tr><td colspan="${orderTableColspan}">No order history found.</td></tr>`; }
     } catch (error) {
         targetElement.innerHTML = `<tr><td colspan="${orderTableColspan}">Error loading order history: ${error.message}</td></tr>`;
         console.error("Error in loadOrderHistory:", error);
     }
}

// --- Price Update Functions ---

// --- WebSocket Implementation (Preferred) ---
function connectWebSocket(symbol) {
    if (!symbol) { console.warn("WebSocket connect attempt with no symbol."); return; }
    currentSymbolForWebSocket = symbol.toUpperCase();
    const wsSymbol = symbol.toLowerCase();
    const wsUrl = `wss://stream.binance.com:9443/ws/${wsSymbol}@miniTicker`;
    const priceDisplayElement = document.getElementById('current-price-display');

    if (priceWebSocket && priceWebSocket.readyState !== WebSocket.CLOSED) { priceWebSocket.close(); }

    console.log(`Connecting to WebSocket: ${wsUrl}`);
    if (priceDisplayElement) priceDisplayElement.innerHTML = '<span class="loading">Connecting...</span>';
    priceWebSocket = new WebSocket(wsUrl);

    priceWebSocket.onopen = function(event) { console.log(`WebSocket connected for ${currentSymbolForWebSocket}`); };

    priceWebSocket.onmessage = function(event) {
        try {
            const data = JSON.parse(event.data);
            if (data && data.c) {
                 const price = parseFloat(data.c);
                 currentPrice = price;
                 if (priceDisplayElement) {
                    priceDisplayElement.textContent = formatCurrency(price);
                    priceDisplayElement.classList.remove('error');
                    priceDisplayElement.classList.add('updated'); setTimeout(() => priceDisplayElement.classList.remove('updated'), 300);
                 }
                 updateTradeFormUI();
            }
        } catch (e) { console.error("Error processing WebSocket message:", e); }
    };

    priceWebSocket.onerror = function(event) {
        console.error(`WebSocket error for ${currentSymbolForWebSocket}:`, event);
        if (priceDisplayElement) { priceDisplayElement.innerHTML = '<span class="loading error">Price Error</span>'; priceDisplayElement.classList.add('error');}
        currentPrice = 0; updateTradeFormUI();
    };

    priceWebSocket.onclose = function(event) {
        console.log(`WebSocket closed for ${currentSymbolForWebSocket}. Code: ${event.code}, Clean: ${event.wasClean}`);
        if (priceDisplayElement && !event.wasClean) {
             priceDisplayElement.innerHTML = '<span class="loading error">Disconnected</span>'; priceDisplayElement.classList.add('error');
             currentPrice = 0; updateTradeFormUI();
        }
        // Reconnect logic (optional)
        // if (!event.wasClean && currentSymbolForWebSocket) { setTimeout(() => connectWebSocket(currentSymbolForWebSocket), 5000); }
    };
}

// --- Trade Page Specific Functions ---

/**
 * Populates the symbol dropdown menu.
 */
async function populateSymbolDropdown(selectElementId, initialSymbol) {
    const selectEl = document.getElementById(selectElementId);
    if (!selectEl) return;
    console.log("Populating symbol dropdown...");
    selectEl.disabled = true;
    try {
        const allSymbolsData = await apiCall('api/search_symbols.php?limit=1500');
        if (allSymbolsData && Array.isArray(allSymbolsData)) {
             console.log(`Fetched ${allSymbolsData.length} symbols.`);
             const quoteAssets = ['USDT', 'BUSD', 'BTC', 'ETH', 'USDC']; // Prioritize these quotes
             const filteredSymbols = allSymbolsData.filter(s => s.symbol && quoteAssets.some(q => s.symbol.endsWith(q)));
             filteredSymbols.sort((a, b) => a.symbol.localeCompare(b.symbol));
             selectEl.innerHTML = '';
             filteredSymbols.forEach(symbolInfo => {
                 const option = document.createElement('option');
                 option.value = symbolInfo.symbol; option.textContent = symbolInfo.symbol;
                 if (symbolInfo.symbol === initialSymbol) { option.selected = true; }
                 selectEl.appendChild(option);
             });
             selectEl.disabled = false;
             console.log("Symbol dropdown populated.");
             updateUIForNewSymbol(selectEl.value); // Trigger initial UI update
        } else { throw new Error("Invalid symbol data received"); }
    } catch (error) {
        console.error("Error populating symbol dropdown:", error);
        selectEl.innerHTML = '<option value="">Error loading symbols</option>';
        updateUIForNewSymbol(initialSymbol); // Try to init with default anyway
    }
}

/**
 * Updates labels, triggers price and balance loading for a new symbol.
 */
function updateUIForNewSymbol(newSymbol) {
    const symbolInputHidden = document.getElementById('trade-symbol');
    const symbolFormInput = document.getElementById('trade-symbol-form');
    const baseAssetInputHidden = document.getElementById('base-asset');
    const quoteAssetInputHidden = document.getElementById('quote-asset');
    const assetLabel = document.getElementById('asset-label');
    const assetLabelForm = document.getElementById('asset-label-form');
    const quoteAssetLabel = document.getElementById('quote-asset-label');
    const quoteAssetTotalLabel = document.getElementById('quote-asset-total-label');
    const priceDisplayElement = document.querySelector('.price-display'); // Select the container div

    if (!newSymbol || !symbolInputHidden || !symbolFormInput || !baseAssetInputHidden || !quoteAssetInputHidden) {
         console.error("Missing critical elements for UI update."); return;
    }
    console.log(`Updating UI for symbol: ${newSymbol}`);
    currentSymbolForWebSocket = newSymbol.toUpperCase(); // Update for WebSocket

    symbolInputHidden.value = currentSymbolForWebSocket;
    symbolFormInput.value = currentSymbolForWebSocket;
    symbolInputHidden.dispatchEvent(new Event('change')); // Trigger for chart_init.js

    let base = 'UNK'; let quote = 'UNK';
    const commonQuotes = ['USDT', 'BUSD', 'USDC', 'TUSD', 'DAI', 'BTC', 'ETH', 'BNB'];
    for (const q of commonQuotes) { if (currentSymbolForWebSocket.endsWith(q)) { base = currentSymbolForWebSocket.substring(0, currentSymbolForWebSocket.length - q.length); quote = q; break; } }
    if (base === 'UNK' && currentSymbolForWebSocket.length > 3) { base = currentSymbolForWebSocket.substring(0, 3); quote = currentSymbolForWebSocket.substring(3); }

    baseAssetInputHidden.value = base; quoteAssetInputHidden.value = quote;
    if(assetLabel) assetLabel.textContent = base; if(assetLabelForm) assetLabelForm.textContent = base;
    if (quoteAssetLabel) quoteAssetLabel.textContent = quote; if (quoteAssetTotalLabel) quoteAssetTotalLabel.textContent = quote;

    // Update Price Display Symbol Title
     if (priceDisplayElement) {
          const priceSpan = document.getElementById('current-price-display');
          if (priceSpan) {
              priceDisplayElement.childNodes[0].nodeValue = `${currentSymbolForWebSocket}: `; // Update text node before span
              priceSpan.innerHTML = '<span class="loading">Loading...</span>'; // Reset span content
          }
     }

     // Use WebSocket to connect for the new symbol's price updates
     connectWebSocket(currentSymbolForWebSocket);
     // --- OR --- Use polling if WebSockets disabled:
     // if (typeof startPriceUpdates === 'function') { startPriceUpdates(currentSymbolForWebSocket, 'current-price-display'); }
     // else { console.error("startPriceUpdates function not found."); }

     if (typeof loadTradeBalances === 'function') { loadTradeBalances('available-cash', 'available-asset', base); }
     else { console.error("loadTradeBalances function not found."); }

     document.title = `Trade ${currentSymbolForWebSocket} - Crypto Paper Trader`;
     updateTradeFormUI(); // Recalculate estimate
}


/**
 * Loads cash and specific asset balance for the trade page.
 * NOTE: For this model, "Available Asset" shows total LONG quantity only.
 */
async function loadTradeBalances(cashElementId, assetElementId, baseAssetSymbol) {
    const cashEl = document.getElementById(cashElementId);
    const assetEl = document.getElementById(assetElementId);
    if (!cashEl || !assetEl) return;
    console.log(`[Trade Balances] Loading for ${baseAssetSymbol}...`);
    cashEl.innerHTML = '<span class="loading">Loading...</span>';
    assetEl.innerHTML = '<span class="loading">Loading...</span>';
    try {
         const data = await apiCall('api/get_portfolio_data.php');
         console.log("[Trade Balances] Data received:", data);
         if (data) {
             cashEl.textContent = formatCurrency(data.cashBalance || 0).replace(/^\$/, '');

             let longAssetQuantity = 0; // Only sum LONG positions for 'available' display
             if (data.holdings && baseAssetSymbol) {
                  data.holdings.forEach(holding => {
                      if (holding.symbol === baseAssetSymbol && holding.direction === 'LONG') {
                          longAssetQuantity += (parseFloat(holding.quantity) || 0);
                      }
                  });
             }
             assetEl.textContent = formatCrypto(longAssetQuantity); // Displays formatted absolute value
             assetEl.classList.remove('quantity-short'); // This display only shows available long quantity
         } else { throw new Error("Empty portfolio data received"); }
    } catch (error) {
        console.error("[Trade Balances] Error loading balances:", error);
        cashEl.textContent = 'Error'; assetEl.textContent = 'Error';
    }
}

/**
 * Updates trade form total estimate and button style based on global `currentPrice`.
 */
function updateTradeFormUI() {
    const quantityInput = document.getElementById('trade-quantity');
    const estimatedTotalDisplay = document.getElementById('estimated-total');
    const tradeButton = document.getElementById('trade-button');
    const buyRadio = document.getElementById('type_buy');
    if(!quantityInput || !estimatedTotalDisplay || !tradeButton || !buyRadio) return;

    const quantity = parseFloat(quantityInput.value) || 0;
    const total = quantity * currentPrice; // Use global currentPrice
    estimatedTotalDisplay.textContent = total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 8 });

    if (buyRadio.checked) { tradeButton.textContent = `Place Buy (Long)`; tradeButton.className = 'trade-button buy'; }
    else { tradeButton.textContent = `Place Sell (Short)`; tradeButton.className = 'trade-button sell'; }
}

/**
 * Handles submission of the main trade form (Opens NEW positions).
 */
async function handleTradeSubmit(event) {
    event.preventDefault();
    const form = event.target;
    const submitButton = form.querySelector('button[type="submit"]');
    const messageDiv = document.getElementById('trade-message');
    if(!submitButton || !messageDiv) return;

    messageDiv.textContent = ''; messageDiv.className = 'trade-message';
    submitButton.disabled = true; submitButton.textContent = 'Processing...';
    const formData = new FormData(form);
    const tradeData = Object.fromEntries(formData.entries()); // Contains symbol, type, quantity

    if (!tradeData.symbol || !tradeData.type || !tradeData.quantity || parseFloat(tradeData.quantity) <= 0) {
        messageDiv.textContent = 'Please fill quantity (> 0).'; messageDiv.classList.add('error');
        submitButton.disabled = false; submitButton.textContent = `Place ${tradeData.type === 'BUY' ? 'Buy (Long)' : 'Sell (Short)'}`;
        return;
    }

    try {
        // API call payload is fine as is for OPEN orders
        const result = await apiCall('api/place_order.php', { method: 'POST', body: JSON.stringify(tradeData) });
        messageDiv.textContent = result.message || 'Order placed successfully!'; messageDiv.classList.add('success');
        // Don't reset the whole form, just quantity? Or leave it? Let's clear quantity.
        const qtyInput = form.querySelector('#trade-quantity');
        if(qtyInput) qtyInput.value = '';
        updateTradeFormUI(); // Reset estimated total

        // Refresh balances after trade
        const baseAssetInput = document.getElementById('base-asset');
        if (baseAssetInput && typeof loadTradeBalances === 'function') {
            setTimeout(() => loadTradeBalances('available-cash', 'available-asset', baseAssetInput.value), 500);
        }
    } catch (error) {
        messageDiv.textContent = `Error placing order: ${error.message || 'Unknown error'}`; messageDiv.classList.add('error');
        console.error('Trade submission error:', error);
    } finally {
        submitButton.disabled = false;
        const typeInput = form.querySelector('input[name="type"]:checked');
        submitButton.textContent = `Place ${(typeInput?.value === 'BUY' ? 'Buy (Long)' : 'Sell (Short)')}`;
    }
}


/**
 * Event Listener for Portfolio Action Buttons (Handles CLOSING positions).
 */
document.addEventListener('click', async function(event) {
    // Check if the clicked element is an action button
    if (event.target && event.target.classList.contains('action-position-btn')) {
        const button = event.target;
        const positionId = button.dataset.positionId; // *** Get Position ID ***
        const symbol = button.dataset.symbol;
        const pair = button.dataset.pair;
        const messageDiv = document.getElementById('portfolio-action-message');

         if(messageDiv) { messageDiv.textContent = ''; messageDiv.className='portfolio-action-message'; }

         if (!positionId || !symbol || !pair) { // Check positionId
             console.error("Missing/invalid data attributes on action button:", button.dataset);
             if(messageDiv) { messageDiv.textContent = 'Error: Cannot process action. Invalid button data.'; messageDiv.className = 'error'; }
             return;
         }

         // Confirmation still good, verb derived from button text now? Or pass direction?
         // Let's keep derivation based on class for simplicity
         const isClosingShort = button.classList.contains('exit-short');
         const actionVerb = isClosingShort ? 'Buy to Close' : 'Sell to Close';

         if (!confirm(`Are you sure you want to ${actionVerb} position ID ${positionId} (${symbol})?`)) {
             return;
         }

         console.log(`${actionVerb}: Position ID ${positionId} (${symbol} via ${pair})`);
         button.disabled = true; button.textContent = 'Processing...';

         try {
             // *** Payload now includes position_id to indicate a CLOSE action ***
             const payload = {
                 position_id: positionId
                 // API will determine type and quantity from position ID
             };

             const result = await apiCall('api/place_order.php', {
                 method: 'POST',
                 body: JSON.stringify(payload)
             });

             console.log("Close order result:", result);
             if(messageDiv) { messageDiv.textContent = result.message || 'Close order placed successfully!'; messageDiv.className = 'success'; }

             // Refresh Portfolio View
             setTimeout(() => { if (typeof loadFullPortfolio === 'function') { loadFullPortfolio('portfolio-full-details'); } }, 500);

         } catch (error) {
              console.error("Error placing close order:", error);
              if(messageDiv) { messageDiv.textContent = `Error closing position: ${error.message || 'Unknown error'}`; messageDiv.className = 'error'; }
              button.disabled = false; button.textContent = actionVerb;
         }
    }
});


// --- DOMContentLoaded Listener - Unified Initial Calls ---
document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM Loaded. Initializing...");

    // --- Dashboard ---
    if (document.getElementById('market-overview')) { loadMarketOverview('market-overview'); }
    if (document.getElementById('portfolio-summary-content')) { loadPortfolioSummary('portfolio-summary-content'); }

    // --- Portfolio Page ---
    if (document.getElementById('portfolio-full-details')) { loadFullPortfolio('portfolio-full-details'); }

    // --- Trade Page ---
    if (document.getElementById('trade-form')) {
         console.log("Initializing trade page...");
         const initialSymbol = document.getElementById('trade-symbol')?.value || 'BTCUSDT';
         if (typeof populateSymbolDropdown === 'function') { populateSymbolDropdown('symbol-select', initialSymbol); }
         else { console.error("populateSymbolDropdown function is not defined!"); }

         // Attach listeners needed on trade page
         const quantityInput = document.getElementById('trade-quantity');
         const priceDisplay = document.getElementById('current-price-display');
         const buyRadio = document.getElementById('type_buy');
         const sellRadio = document.getElementById('type_sell');
         const tradeForm = document.getElementById('trade-form');
         const symbolSelect = document.getElementById('symbol-select');

         if(quantityInput) quantityInput.addEventListener('input', updateTradeFormUI);
         const observer = new MutationObserver(() => updateTradeFormUI());
         if(priceDisplay) observer.observe(priceDisplay, { childList: true, characterData: true, subtree: true });
         if(buyRadio) buyRadio.addEventListener('change', updateTradeFormUI);
         if(sellRadio) sellRadio.addEventListener('change', updateTradeFormUI);
         if (tradeForm && typeof handleTradeSubmit === 'function') { tradeForm.addEventListener('submit', handleTradeSubmit); }
         else { console.error("Trade form or handleTradeSubmit function not found."); }
         if (symbolSelect) {
             symbolSelect.addEventListener('change', function(event) {
                  const newSymbol = event.target.value;
                  if (newSymbol && typeof updateUIForNewSymbol === 'function') { updateUIForNewSymbol(newSymbol); }
                  else if (!newSymbol) { console.log("Dropdown changed to empty value."); }
                  else { console.error("updateUIForNewSymbol function not defined!"); }
             });
         }
         // Initial UI update for form button text etc.
         updateTradeFormUI();
    }

     // --- Orders Page ---
      if (document.getElementById('orders-history-list')) { loadOrderHistory('orders-history-list'); }

      console.log("Initialization complete.");

    // Add this inside the main DOMContentLoaded event listener in assets/js/script.js

const addCashForm = document.getElementById('add-cash-form');
if (addCashForm) {
    console.log("Add cash form found. Attaching listener.");
    addCashForm.addEventListener('submit', async function(event) {
        event.preventDefault(); // Prevent traditional form submission

        const amountInput = document.getElementById('add_amount');
        const messageDiv = document.getElementById('add-cash-message');
        const submitButton = document.getElementById('add-cash-button');
        if (!amountInput || !messageDiv || !submitButton) return; // Ensure elements exist

        const amount = parseFloat(amountInput.value);

        // Basic client-side validation
        if (isNaN(amount) || amount <= 0) {
            messageDiv.textContent = 'Please enter a valid positive amount.';
            messageDiv.className = 'error'; // Use CSS class for styling
            return;
        }

        messageDiv.textContent = 'Processing...';
        messageDiv.className = ''; // Clear previous status
        submitButton.disabled = true;

        try {
            const payload = { amount: amount };
            const result = await apiCall('api/add_cash_process.php', {
                method: 'POST',
                body: JSON.stringify(payload)
            });

            messageDiv.textContent = result.message || 'Cash added successfully!';
            messageDiv.className = 'success';
            amountInput.value = ''; // Clear input field

            // --- Refresh relevant portfolio/balance displays ---
            console.log("Add cash successful. Refreshing portfolio sections...");
            // Option 1: Reload specific sections if they exist on the current page
            if (typeof loadPortfolioSummary === 'function' && document.getElementById('portfolio-summary-content')) {
                loadPortfolioSummary('portfolio-summary-content');
            }
            if (typeof loadFullPortfolio === 'function' && document.getElementById('portfolio-full-details')) {
                loadFullPortfolio('portfolio-full-details');
            }
            if (typeof loadTradeBalances === 'function' && document.getElementById('trade-form')) {
                const baseAsset = document.getElementById('base-asset')?.value;
                if(baseAsset) loadTradeBalances('available-cash', 'available-asset', baseAsset);
            }
            // Option 2: Update specific balance elements directly if you know their IDs and have newBalance
            // const cashEl = document.getElementById('portfolio-cash-balance'); // etc.
            // if (cashEl && typeof result.newBalance !== 'undefined') {
            //    cashEl.textContent = formatCurrency(result.newBalance);
            // }


        } catch (error) {
            messageDiv.textContent = `Error: ${error.message || 'Could not add cash.'}`;
            messageDiv.className = 'error';
            console.error("Error adding cash:", error);
        } finally {
            submitButton.disabled = false; // Re-enable button
        }
    });
} else {
    console.log("Add cash form not found on this page.");
}

const removeCashForm = document.getElementById('remove-cash-form');
if (removeCashForm) {
    console.log("Remove cash form found. Attaching listener.");
    removeCashForm.addEventListener('submit', async function(event) {
        event.preventDefault(); // Prevent traditional form submission

        const amountInput = document.getElementById('remove_amount'); // Use ID from remove form
        const messageDiv = document.getElementById('remove-cash-message'); // Use ID from remove form
        const submitButton = document.getElementById('remove-cash-button'); // Use ID from remove form
        if (!amountInput || !messageDiv || !submitButton) {
            console.error("Required elements for remove cash form not found!");
            return;
        }

        const amount = parseFloat(amountInput.value);

        // Basic client-side validation
        if (isNaN(amount) || amount <= 0) {
            messageDiv.textContent = 'Please enter a valid positive amount.';
            messageDiv.className = 'cash-form-message error'; // Use specific class
            return;
        }

        messageDiv.textContent = 'Processing...';
        messageDiv.className = 'cash-form-message'; // Clear previous status
        submitButton.disabled = true;

        try {
            const payload = { amount: amount };
            const result = await apiCall('api/remove_cash_process.php', { // Call correct API endpoint
                method: 'POST',
                body: JSON.stringify(payload) // *** IMPORTANT: Stringify the payload ***
            });

            messageDiv.textContent = result.message || 'Cash removed successfully!';
            messageDiv.className = 'cash-form-message success';
            amountInput.value = ''; // Clear input field

            // --- Refresh relevant portfolio/balance displays ---
            console.log("Remove cash successful. Refreshing portfolio sections...");
            // Reload specific sections if they exist on the current page
            if (typeof loadPortfolioSummary === 'function' && document.getElementById('portfolio-summary-content')) {
                loadPortfolioSummary('portfolio-summary-content');
            }
            if (typeof loadFullPortfolio === 'function' && document.getElementById('portfolio-full-details')) {
                loadFullPortfolio('portfolio-full-details');
            }
            if (typeof loadTradeBalances === 'function' && document.getElementById('trade-form')) {
                const baseAsset = document.getElementById('base-asset')?.value;
                if(baseAsset) loadTradeBalances('available-cash', 'available-asset', baseAsset);
            }

        } catch (error) {
            // Display specific error from API if available, otherwise generic
            messageDiv.textContent = `Error: ${error.message || 'Could not remove cash.'}`;
            messageDiv.className = 'cash-form-message error';
            console.error("Error removing cash:", error);
        } finally {
            submitButton.disabled = false; // Re-enable button
        }
    });
} else {
    console.log("Remove cash form not found on this page.");
}
}); // End DOMContentLoaded