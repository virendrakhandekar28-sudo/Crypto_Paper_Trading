/**
 * chart_init.js
 *
 * Initializes the TradingView Advanced Real-Time Chart Widget.
 * Assumes the main TradingView widget script is already included in the HTML.
 * Listens for changes in the selected symbol to update the chart.
 */

document.addEventListener('DOMContentLoaded', function() {

    const chartContainerId = 'tv_chart_container'; // ID of the div where the chart will load
    const chartContainer = document.getElementById(chartContainerId);
    // --- Element holding the current trading symbol (e.g., BTCUSDT) ---
    // Option 1: An input field (hidden or visible)
    const symbolInputElement = document.getElementById('trade-symbol');
    // Option 2: A select dropdown (if you use one)
    // const symbolSelectElement = document.getElementById('trade-symbol-select');
    // Option 3: A data attribute on the container itself
    // const initialSymbolFromData = chartContainer ? chartContainer.dataset.symbol : null;

    // Check if the container element exists
    if (!chartContainer) {
        console.error(`TradingView chart container element with ID #${chartContainerId} was not found.`);
        return; // Stop if no container
    }

    // --- Function to Load/Reload the TradingView Widget ---
    function loadTradingViewWidget(symbol) {
        // Basic validation for the symbol
        if (!symbol || typeof symbol !== 'string' || symbol.trim() === '') {
            console.error('Invalid or missing symbol provided for TradingView Widget:', symbol);
            // Display an error in the chart container
            chartContainer.innerHTML = '<p style="padding: 20px; text-align: center;">Error: No valid trading symbol selected.</p>';
            return;
        }

        // Check if TradingView library is loaded (it should be if the main script was included)
        if (typeof TradingView === 'undefined' || !TradingView || !TradingView.widget) {
            console.error('TradingView library (TradingView.widget) is not loaded. Ensure the main widget script is included correctly in your HTML before chart_init.js.');
            chartContainer.innerHTML = '<p style="padding: 20px; text-align: center;">Error: Chart library failed to load.</p>';
            return;
        }

        console.log(`Initializing TradingView Widget for symbol: BINANCE:${symbol.toUpperCase()}`);

        // Clear the container before loading a new widget (prevents stacking widgets)
        chartContainer.innerHTML = '';

        try {
            new TradingView.widget({
                // --- Essential ---
                "container_id": chartContainerId, // The ID of the container div
                "symbol": `BINANCE:${symbol.toUpperCase()}`, // The core setting - Prefixes with Binance
                "interval": "15", // Default timeframe (e.g., 15 min. Others: '1', '60', 'D', 'W', 'M')

                // --- Size & Appearance ---
                "width": "100%", // Make it responsive horizontally
                "height": "100%", // Make it responsive vertically (container MUST have a defined height via CSS)
                "theme": "light", // Options: "light", "dark"
                "style": "1", // Candlestick type (1: Bars, 2: Candles, 3: Line, etc.)
                "locale": "en", // Language

                // --- Features & Toolbar ---
                "toolbar_bg": "#f1f3f6", // Background for the top toolbar
                "enable_publishing": false, // Disable snapshot/publishing buttons
                "hide_side_toolbar": false, // Show drawing tools toolbar on the left
                "allow_symbol_change": true, // Allow user to change symbol *within* the widget (optional)
                "save_image": false, // Disable the save chart image button

                // --- Data & Loading ---
                "timezone": "Etc/UTC", // Or "exchange" or a specific one like "America/New_York"
                "autosize": true, // Usually good with width/height 100%

                // --- Optional Defaults ---
                "studies": [ // Add default technical indicators
                   // Example: Moving Average
                   // { "id": "MASimple@tv-basicstudies", "inputs": { "length": 20 } },
                   // Example: Volume
                   "Volume@tv-basicstudies"
                ],
                // "withdateranges": true, // Show date range selector at the bottom

                // For more options, see TradingView Widget documentation:
                // https://www.tradingview.com/widget/documentation/
            });
        } catch (error) {
             console.error("Error creating TradingView Widget:", error);
             chartContainer.innerHTML = '<p style="padding: 20px; text-align: center;">Error initializing chart.</p>';
        }
    }

    // --- Initial Widget Load ---
    let currentSymbol = 'BTCUSDT'; // Default if no other source found
    if (symbolInputElement && symbolInputElement.value) {
        currentSymbol = symbolInputElement.value;
    }
    // Add checks for other sources (select element, data attribute) if needed
    // else if (symbolSelectElement && symbolSelectElement.value) { currentSymbol = symbolSelectElement.value; }
    // else if (initialSymbolFromData) { currentSymbol = initialSymbolFromData; }

    loadTradingViewWidget(currentSymbol);


    // --- Event Listener for Symbol Changes ---
    // Add a listener to the element that controls the symbol choice.
    // This example assumes the 'trade-symbol' input's value changes.
    if (symbolInputElement) {
        symbolInputElement.addEventListener('change', function(event) {
            const newSymbol = event.target.value;
            if (newSymbol && newSymbol !== currentSymbol) {
                console.log(`Symbol changed via input. Reloading chart for: ${newSymbol}`);
                currentSymbol = newSymbol; // Update the tracked symbol
                loadTradingViewWidget(currentSymbol);
            }
        });
    }

    // If using a select dropdown:
    // if (symbolSelectElement) {
    //     symbolSelectElement.addEventListener('change', function(event) {
    //         const newSymbol = event.target.value;
    //         if (newSymbol && newSymbol !== currentSymbol) {
    //             console.log(`Symbol changed via select. Reloading chart for: ${newSymbol}`);
    //             currentSymbol = newSymbol;
    //             loadTradingViewWidget(currentSymbol);
    //         }
    //     });
    // }

    // Listen for custom events if the symbol changes in other ways
    // document.addEventListener('symbolUpdated', function(event) {
    //      const newSymbol = event.detail.symbol;
    //       if (newSymbol && newSymbol !== currentSymbol) {
    //             console.log(`Symbol changed via custom event. Reloading chart for: ${newSymbol}`);
    //             currentSymbol = newSymbol;
    //             loadTradingViewWidget(currentSymbol);
    //         }
    // });


}); // End DOMContentLoaded