<?php
/**
 * includes/trading_logic.php
 *
 * Contains core business logic for paper trading simulation,
 * such as portfolio valuation, P/L calculations, etc.
 *
 * Note: The primary trade execution logic (transaction, locking)
 * currently resides in api/place_order.php for simplicity in this example.
 * For larger applications, that logic would ideally be refactored into
 * functions within this file or a dedicated TradingService class.
 */

// Ensure dependencies are available when functions are called
// require_once __DIR__ . '/database.php'; // Usually included by the caller
// require_once __DIR__ . '/binance_api.php'; // Usually included by the caller
// require_once __DIR__ . '/functions.php'; // Usually included by the caller


// --- Custom Exception Classes (Optional but helpful) ---
class TradingLogicException extends Exception {}
class InsufficientFundsException extends TradingLogicException {}
class InsufficientAssetsException extends TradingLogicException {}


/**
 * Calculates the current total value of a user's portfolio.
 * Fetches cash balance and current value of all crypto holdings.
 *
 * @param PDO $pdo The PDO database connection object.
 * @param int $user_id The ID of the user.
 * @return array Associative array ['totalValue' => float, 'cashBalance' => float, 'cryptoValue' => float]
 * @throws Exception if database or API errors occur.
 */
function calculatePortfolioValue(PDO $pdo, int $user_id): array
{
    $result = [
        'totalValue' => 0.00,
        'cashBalance' => 0.00,
        'cryptoValue' => 0.00,
    ];
    $symbols_to_fetch = [];
    $db_holdings = [];

    try {
        // 1. Fetch Cash Balance
        $sql_cash = "SELECT cash_balance FROM portfolios WHERE user_id = :user_id LIMIT 1";
        $stmt_cash = $pdo->prepare($sql_cash);
        $stmt_cash->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_cash->execute();
        $cash_result = $stmt_cash->fetch(PDO::FETCH_ASSOC);
        $result['cashBalance'] = $cash_result ? (float)$cash_result['cash_balance'] : 0.00;

        // 2. Fetch Crypto Holdings (Symbols and Quantities)
        $sql_assets = "SELECT symbol, quantity FROM portfolio_assets WHERE user_id = :user_id AND quantity > 0";
        $stmt_assets = $pdo->prepare($sql_assets);
        $stmt_assets->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_assets->execute();
        $db_holdings = $stmt_assets->fetchAll(PDO::FETCH_ASSOC);

        // Collect symbols for price fetching
        foreach ($db_holdings as $holding) {
            // Assume symbol is base asset (e.g., 'BTC') and we trade against USDT
            $trading_pair = $holding['symbol'] . 'USDT'; // Needs robust handling based on actual pairs
            $symbols_to_fetch[$holding['symbol']] = $trading_pair;
        }

    } catch (PDOException $e) {
        error_log("DB Error calculating portfolio value for user $user_id: " . $e->getMessage());
        throw new Exception("Database error retrieving portfolio data."); // Re-throw generic exception
    }

    // 3. Fetch Live Prices (Requires binance_api.php)
    $live_prices = [];
    if (!empty($symbols_to_fetch)) {
        if (!function_exists('fetchMultipleCryptoPrices')) {
             throw new Exception("Required function fetchMultipleCryptoPrices() not found. Ensure binance_api.php is included.");
        }
        try {
            $unique_trading_pairs = array_unique(array_values($symbols_to_fetch));
            // Fetch prices using the function from binance_api.php
            $live_prices = fetchMultipleCryptoPrices($unique_trading_pairs);
        } catch (Exception $e) {
            error_log("API Error calculating portfolio value for user $user_id: " . $e->getMessage());
            // Decide how to handle: throw error or return partial value?
            throw new Exception("Failed to fetch live market prices for valuation.");
        }
    }

    // 4. Calculate Crypto Value
    $total_crypto_value = 0.00;
    foreach ($db_holdings as $holding) {
        $symbol = $holding['symbol'];
        $quantity = (float)$holding['quantity'];
        $trading_pair = $symbols_to_fetch[$symbol] ?? null;

        $current_price = 0.00;
        if ($trading_pair && isset($live_prices[$trading_pair])) {
            $current_price = (float)$live_prices[$trading_pair];
        } else {
             error_log("Missing live price for pair: " . ($trading_pair ?? $symbol) . " during portfolio valuation for user $user_id.");
             // Skip this asset's value if price is missing
        }
        $total_crypto_value += ($quantity * $current_price);
    }

    $result['cryptoValue'] = $total_crypto_value;
    $result['totalValue'] = $result['cashBalance'] + $result['cryptoValue'];

    return $result;
}


/*
 * Example structure if trade logic were refactored here:
 * (This is NOT fully implemented, just showing the concept)
 */
/*
function executePaperTrade(PDO $pdo, int $user_id, string $trading_pair, string $order_type, float $quantity, float $execution_price): bool
{
    $order_type = strtoupper($order_type);
    $base_asset = determineBaseAsset($trading_pair); // Helper needed

    $pdo->beginTransaction();
    try {
        // 1. Lock and get cash balance
        $current_cash = getLockedCashBalance($pdo, $user_id);

        // 2. Lock and get asset balance (if selling)
        $asset_data = ($order_type === 'SELL') ? getLockedAssetData($pdo, $user_id, $base_asset) : null;
        $current_asset_quantity = $asset_data['quantity'] ?? 0.0;

        // 3. Calculate total value
        $total_value = $quantity * $execution_price;

        // 4. Check funds / assets
        if ($order_type === 'BUY' && $current_cash < $total_value) {
            throw new InsufficientFundsException("Insufficient funds.");
        }
        if ($order_type === 'SELL' && $current_asset_quantity < $quantity) {
             throw new InsufficientAssetsException("Insufficient assets.");
        }

        // 5. Calculate new balances/cost basis
        // ... complex logic for cost basis adjustment ...
        $new_cash_balance = ($order_type === 'BUY') ? ($current_cash - $total_value) : ($current_cash + $total_value);
        // ... $new_asset_quantity, $new_cost_basis ...

        // 6. Update cash in DB
        updateCashBalance($pdo, $user_id, $new_cash_balance);

        // 7. Update/Insert asset in DB
        updateOrInsertAsset($pdo, $user_id, $base_asset, $new_asset_quantity, $new_cost_basis);

        // 8. Record order in DB
        recordOrderHistory($pdo, $user_id, $trading_pair, $order_type, $quantity, $execution_price, $total_value);

        $pdo->commit();
        return true;

    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Trade execution failed for user $user_id: " . $e->getMessage());
        // Re-throw specific exception types if needed
        if ($e instanceof InsufficientFundsException || $e instanceof InsufficientAssetsException) {
            throw $e;
        }
        throw new TradingLogicException("Trade execution failed due to a server error.", 0, $e);
    }
}

// --- Helper sub-functions for executePaperTrade (need implementation) ---
function determineBaseAsset(string $trading_pair): string { // ... logic ... }
function getLockedCashBalance(PDO $pdo, int $user_id): float { // ... SELECT ... FOR UPDATE ... }
function getLockedAssetData(PDO $pdo, int $user_id, string $symbol): ?array { // ... SELECT ... FOR UPDATE ... }
function updateCashBalance(PDO $pdo, int $user_id, float $new_balance): void { // ... UPDATE ... }
function updateOrInsertAsset(PDO $pdo, int $user_id, string $symbol, float $new_qty, float $new_cost): void { // ... INSERT or UPDATE ... }
function recordOrderHistory(PDO $pdo, int $user_id, string $pair, string $type, float $qty, float $price, float $total): void { // ... INSERT ... }

*/


?>