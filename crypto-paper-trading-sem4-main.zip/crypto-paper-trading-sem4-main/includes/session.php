<?php
/**
 * session.php
 *
 * Configures and starts the PHP session.
 * This file should be included at the VERY TOP of any PHP script
 * that needs to access session data (e.g., check login status, store user ID).
 */

// --- Session Configuration (Recommended Security Settings) ---

// Set session cookie parameters for better security.
// Adjust settings based on your environment (especially 'secure').
ini_set('session.use_only_cookies', 1); // Ensure session ID is only passed via cookies
ini_set('session.cookie_httponly', 1); // Prevent JavaScript access to the session cookie
ini_set('session.use_strict_mode', 1); // Prevent user-defined session IDs

// Set cookie lifetime (optional, 0 = until browser closes)
// ini_set('session.cookie_lifetime', 0);

// Set SameSite attribute (Lax is often a good balance, Strict is more secure but can break some cross-site workflows)
// Requires PHP 7.3+
if (PHP_VERSION_ID >= 70300) {
    session_set_cookie_params([
        'lifetime' => 0, // Adjust as needed
        'path' => '/', // Available to entire domain
        // 'domain' => '.yourdomain.com', // Set if using subdomains
        'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on', // IMPORTANT: Set to true if using HTTPS
        'httponly' => true,
        'samesite' => 'Lax' // Or 'Strict'
    ]);
} else {
     // Fallback for older PHP versions (less secure SameSite handling)
     session_set_cookie_params(
        0,
        '/',
        // '.yourdomain.com', // Set if using subdomains
        isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
        true
    );
}

// --- Start the Session ---

// Start or resume the session. This MUST be called before any output is sent to the browser.
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// --- Optional: Session Timeout/Regeneration Logic ---
/*
// Example: Regenerate session ID periodically to prevent session fixation
if (!isset($_SESSION['last_regeneration'])) {
    $_SESSION['last_regeneration'] = time();
} elseif (time() - $_SESSION['last_regeneration'] > 1800) { // Regenerate every 30 minutes
    session_regenerate_id(true); // true = delete old session file
    $_SESSION['last_regeneration'] = time();
}

// Example: Session timeout
$timeout_duration = 3600; // 1 hour inactivity timeout
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Last request was more than 1 hour ago
    session_unset();     // Unset $_SESSION variable for the run-time
    session_destroy();   // Destroy session data in storage
    // Optionally redirect to login or show message
    // header("Location: login.php?timeout=1");
    // exit;
}
$_SESSION['last_activity'] = time(); // Update last activity time stamp
*/

