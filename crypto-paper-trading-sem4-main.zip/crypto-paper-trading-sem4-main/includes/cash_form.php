<?php
/**
 * includes/cash_forms.php
 *
 * Provides side-by-side HTML forms for adding and removing virtual cash.
 */
?>
<section class="cash-management-section dashboard-section"> <!-- Main container section -->
    <h3>Manage Virtual Cash</h3>
    <div class="cash-forms-container"> <!-- Flex container -->

        <!-- Add Cash Form Section -->
        <div class="cash-form add-cash-form">
            <h4>Add Cash</h4>
            <form id="add-cash-form" action="api/add_cash_process.php" method="POST">
                <div class="form-group">
                    <label for="add_amount">Amount:</label>
                    <input type="number" id="add_amount" name="amount" step="0.01" min="0.01" placeholder="e.g., 1000" required>
                 </div>
                 <div class="form-group">
                    <button type="submit" id="add-cash-button" class="trade-button buy">Add Cash</button>
                </div>
                <div id="add-cash-message" class="cash-form-message"></div>
            </form>
        </div>

        <!-- Remove Cash Form Section -->
        <div class="cash-form remove-cash-form">
            <h4>Remove Cash</h4>
            <form id="remove-cash-form" action="api/remove_cash_process.php" method="POST">
                <div class="form-group">
                    <label for="remove_amount">Amount:</label>
                    <input type="number" id="remove_amount" name="amount" step="0.01" min="0.01" placeholder="e.g., 1000" required>
                 </div>
                 <div class="form-group">
                    <button type="submit" id="remove-cash-button" class="trade-button sell">Remove Cash</button>
                </div>
                <div id="remove-cash-message" class="cash-form-message"></div>
            </form>
        </div>

    </div> <!-- End Flex container -->

    <style>
        /* Styles specific to the cash management section */
        .cash-management-section {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee; /* Optional separator */
        }
        .cash-management-section h3 {
            text-align: left;
            margin-bottom: 20px;
            font-size: 1.2em;
            color: #333;
        }
        .cash-forms-container {
            display: flex;
            flex-wrap: wrap; /* Allow wrapping on small screens */
            gap: 40px; /* Space between the two forms */
            justify-content: center; /* Center forms if they wrap */
        }
        .cash-form {
            flex: 1; /* Allow forms to grow */
            min-width: 250px; /* Minimum width before wrapping */
            max-width: 350px; /* Optional max width */
            padding: 20px;
            border: 1px solid #e0e0e0;
            border-radius: 5px;
            background-color: #fdfdfd;
        }
        .cash-form h4 {
            text-align: center;
            margin-bottom: 15px;
            font-size: 1.1em;
            color: #555;
        }
        .cash-form .form-group {
            margin-bottom: 15px;
        }
        .cash-form label {
             display: block; /* Label on its own line */
             margin-bottom: 5px;
             font-size: 0.9em;
        }
        .cash-form input[type="number"] {
             width: 100%; /* Input takes full width */
             padding: 8px 10px;
        }
        .cash-form button {
             width: 100%; /* Button takes full width */
             padding: 10px 15px;
             font-size: 0.95em;
        }
        .cash-form-message {
             margin-top: 15px;
             font-size: 0.9em;
             text-align: center;
             min-height: 1.2em; /* Prevent layout jump */
        }
         /* Message styles (ensure they are defined either here or globally in style.css) */
         .cash-form-message.success {
             background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb;
             display: block; padding: 8px;
        }
         .cash-form-message.error {
             background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;
             display: block; padding: 8px;
         }
    </style>
</section>