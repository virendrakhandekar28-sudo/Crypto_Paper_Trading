<?php
/**
 * includes/database.php
 *
 * Establishes the database connection using PDO.
 * Reads configuration from config.php.
 */

// Include configuration file which holds DB credentials
require_once __DIR__ . '/config.php'; // Use __DIR__ for reliable path

// --- PDO Connection Options ---
// These options configure how PDO behaves.
$options = [
    // Persistent connections can improve performance by reusing connections,
    // but might have issues in some environments/setups. Test carefully.
    // PDO::ATTR_PERSISTENT => true,

    // Set error handling mode to throw exceptions. This is generally preferred
    // as it allows catching database errors using try...catch blocks.
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,

    // Set the default fetch mode to associative arrays.
    // This means fetch() and fetchAll() will return arrays indexed by column name.
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,

    // Optional: Emulate prepared statements (can be useful for older MySQL versions
    // or drivers that don't fully support native prepared statements).
    // Generally better to leave it as false (use native prepares) if possible.
    // PDO::ATTR_EMULATE_PREPARES => false,

    // Optional: Set character set directly in DSN or use options (depends on driver).
    // Usually handled by the charset part of the DSN string.
    // PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET // Older way
];

// --- Construct Data Source Name (DSN) ---
// This string tells PDO how to connect to the database.
$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

// --- Establish Connection ---
try {
    // Create the PDO instance (the database connection object)
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);

    // Connection successful! The $pdo object is now available
    // to any script that includes this file.

} catch (PDOException $e) {
    // If the connection fails, catch the exception.
    // It's crucial *not* to display detailed error messages (like username/password)
    // to the end-user in a production environment.

    // Log the detailed error to the server's error log for the administrator.
    error_log("Database Connection Error: " . $e->getMessage());

    // Display a generic, user-friendly error message and terminate the script.
    // You might want a more sophisticated error page in a real application.
    die("Database connection failed. Please check server logs or contact the administrator. Do not share detailed errors publicly.");
}

// No closing tag is needed if the file only contains PHP code.