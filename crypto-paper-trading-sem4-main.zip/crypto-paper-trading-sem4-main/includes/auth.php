<?php
/**
 * includes/auth.php
 *
 * Handles user authentication and registration logic.
 * Requires database.php to be included beforehand to provide the $pdo object.
 */

// Note: Ensure database.php (which creates $pdo) is included before this file in login.php and register.php

/**
 * Checks if a username already exists in the database.
 *
 * @param PDO $pdo The PDO database connection object.
 * @param string $username The username to check.
 * @return bool True if the username exists, false otherwise.
 */
function isUsernameTaken(PDO $pdo, string $username): bool
{
    try {
        $sql = "SELECT COUNT(*) FROM users WHERE username = :username";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    } catch (PDOException $e) {
        // Log error appropriately in a real application
        error_log("Database error checking username: " . $e->getMessage());
        // Optionally re-throw or handle more gracefully
        // For registration, safer to assume it *might* be taken if DB error occurs
        return true; // Or throw an exception
    }
}

/**
 * Checks if an email address already exists in the database.
 *
 * @param PDO $pdo The PDO database connection object.
 * @param string $email The email address to check.
 * @return bool True if the email exists, false otherwise.
 */
function isEmailTaken(PDO $pdo, string $email): bool
{
    try {
        $sql = "SELECT COUNT(*) FROM users WHERE email = :email";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    } catch (PDOException $e) {
        error_log("Database error checking email: " . $e->getMessage());
        return true; // Safer default on error
    }
}

/**
 * Registers a new user in the database and sets their initial cash balance.
 * Uses a transaction to ensure atomicity.
 *
 * @param PDO $pdo The PDO database connection object.
 * @param string $username The desired username.
 * @param string $email The user's email address.
 * @param string $hashed_password The securely hashed password.
 * @param float $starting_cash The initial virtual cash balance.
 * @return bool True on successful registration, false otherwise.
 */
function registerUser(PDO $pdo, string $username, string $email, string $hashed_password, float $starting_cash): bool
{
    $pdo->beginTransaction(); // Start transaction

    try {
        // 1. Insert into users table
        $sql_user = "INSERT INTO users (username, email, password_hash, created_at) VALUES (:username, :email, :password, NOW())";
        $stmt_user = $pdo->prepare($sql_user);
        $stmt_user->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt_user->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt_user->bindParam(':password', $hashed_password, PDO::PARAM_STR);

        if (!$stmt_user->execute()) {
             // Throw exception if user insert fails
            throw new Exception("Failed to insert user record.");
        }

        // Get the ID of the newly inserted user
        $user_id = $pdo->lastInsertId();

        if (!$user_id) {
             // Throw exception if ID retrieval fails
             throw new Exception("Failed to retrieve last inserted user ID.");
        }

        // 2. Insert initial cash balance (assuming a 'portfolios' table or similar)
        // Adjust table/column names as per your schema
        $sql_balance = "INSERT INTO portfolios (user_id, cash_balance) VALUES (:user_id, :cash)";
        $stmt_balance = $pdo->prepare($sql_balance);
        $stmt_balance->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        // Bind cash balance as string for precision with PDO, DB column should be DECIMAL/NUMERIC
        $cash_str = number_format($starting_cash, 2, '.', '');
        $stmt_balance->bindParam(':cash', $cash_str, PDO::PARAM_STR);


        if (!$stmt_balance->execute()) {
            // Throw exception if balance insert fails
            throw new Exception("Failed to insert initial cash balance.");
        }

        // If both inserts were successful, commit the transaction
        $pdo->commit();
        return true;

    } catch (PDOException | Exception $e) {
        // An error occurred, rollback the transaction
        $pdo->rollBack();
        error_log("Registration transaction failed: " . $e->getMessage());
        return false; // Indicate failure
    }
}


/**
 * Attempts to log in a user by verifying their credentials.
 *
 * @param PDO $pdo The PDO database connection object.
 * @param string $identifier The username or email provided by the user.
 * @param string $password The plain text password provided by the user.
 * @return array|false User data (id, username) as an array on success, false on failure.
 */
function loginUser(PDO $pdo, string $identifier, string $password) // No return type hint allows false
{
    try {
        // Select user based on username OR email
        $sql = "SELECT id, username, password_hash FROM users WHERE username = :identifier OR email = :identifier LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':identifier', $identifier, PDO::PARAM_STR);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if user exists
        if ($user) {
            // Verify the provided password against the stored hash
            if (password_verify($password, $user['password_hash'])) {
                // Password is correct!
                // Return essential user data (don't return the hash!)
                return [
                    'id' => $user['id'],
                    'username' => $user['username']
                    // Add other data needed in the session if required (e.g., role)
                ];
            } else {
                // Password incorrect
                return false;
            }
        } else {
            // User not found
            return false;
        }
    } catch (PDOException $e) {
        error_log("Database error during login: " . $e->getMessage());
        return false; // Indicate failure on DB error
    }
}

?>