<?php
/**
 * includes/functions.php
 *
 * Contains general helper functions for the application.
 */

/**
 * Sanitizes output data to prevent Cross-Site Scripting (XSS) vulnerabilities.
 * Use this whenever you are echoing data that originated from user input or
 * an external source into an HTML context.
 *
 * @param string|null $data The data to sanitize.
 * @return string The sanitized data. Returns an empty string if input was null.
 */
function sanitizeOutput(?string $data): string
{
    if ($data === null) {
        return '';
    }
    // ENT_QUOTES converts both double and single quotes.
    // 'UTF-8' ensures correct handling of multi-byte characters.
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

/**
 * Redirects the user to a specified URL and terminates the script execution.
 *
 * @param string $url The URL to redirect to. Can be relative or absolute.
 * @return void This function does not return a value as it terminates the script.
 */
function redirect(string $url): void
{
    // Prevent header injection vulnerabilities (though less common with simple redirects)
    $url = filter_var($url, FILTER_SANITIZE_URL);
    if ($url === false || empty($url)) {
         $url = 'index.php'; // Default redirect location if URL is invalid/empty
    }
    header('Location: ' . $url);
    exit; // Crucial to stop script execution after sending the header
}

/**
 * Checks if the user is currently logged in based on session data.
 * Assumes session.php has already started the session.
 *
 * @return bool True if the user is logged in, false otherwise.
 */
function isUserLoggedIn(): bool
{
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}


/**
 * Formats a number as currency for display (PHP version).
 * Note: JavaScript's Intl.NumberFormat (in script.js) is generally preferred
 * for client-side display as it handles locale-specific formatting better.
 * This PHP version provides basic formatting.
 *
 * @param float $amount The numeric amount.
 * @param int $decimals Number of decimal places (usually 2 for currency).
 * @param string $decimal_separator Character for the decimal point.
 * @param string $thousands_separator Character for the thousands separator.
 * @return string The formatted currency string (e.g., "10,000.50").
 */
function formatCurrencyPHP(float $amount, int $decimals = 2, string $decimal_separator = '.', string $thousands_separator = ','): string
{
    // Be cautious with float precision for calculations; use BCMath or store as integer cents/satoshis if needed.
    // This function is mainly for basic display formatting.
    return number_format($amount, $decimals, $decimal_separator, $thousands_separator);
}

/**
 * Formats a number representing a cryptocurrency amount for display (PHP version).
 * Typically avoids thousands separators and allows more decimal places.
 *
 * @param float $amount The numeric amount.
 * @param int $decimals Maximum number of decimal places to display.
 * @param string $decimal_separator Character for the decimal point.
 * @param string $thousands_separator Character for the thousands separator (usually empty for crypto).
 * @return string The formatted crypto amount string (e.g., "0.00543210").
 */
function formatCryptoPHP(float $amount, int $decimals = 8, string $decimal_separator = '.', string $thousands_separator = ''): string
{
     // Be cautious with float precision.
    return number_format($amount, $decimals, $decimal_separator, $thousands_separator);
}


/**
 * Simple helper function for debugging. Prints a variable in a readable format.
 * Use only during development! Remove or comment out calls before deployment.
 *
 * @param mixed $data The variable or data structure to dump.
 * @param bool $die Whether to terminate the script after dumping (default: true).
 * @return void
 */
function debug_dump(mixed $data, bool $die = true): void
{
    // Check if output is already HTML or force plain text
    if (php_sapi_name() !== 'cli' && !headers_sent()) {
         echo '<pre style="background-color: #f5f5f5; border: 1px solid #ccc; padding: 10px; margin: 10px; border-radius: 4px; font-family: monospace; white-space: pre-wrap; word-wrap: break-word;">';
    }

    print_r($data); // Or use var_dump($data); for more detailed type/length info

     if (php_sapi_name() !== 'cli' && !headers_sent()) {
         echo '</pre>';
     } elseif (php_sapi_name() === 'cli') {
          echo "\n"; // Add newline for CLI output
     }


    if ($die) {
        die(); // Stop script execution
    }
}

// Add any other general utility functions you find yourself needing below...
// For example, CSRF token generation/validation could go here if not using a framework/library.

