<?php
/**
 * includes/binance_api.php
 *
 * Handles interactions with the public Binance API.
 * Provides functions to fetch prices, exchange info, and ticker data.
 * Includes basic file caching for exchange info.
 */

// --- Configuration ---
define('BINANCE_API_BASE_URL', 'https://api.binance.com');
define('BINANCE_API_TIMEOUT', 10); // cURL timeout in seconds

// Cache settings for exchange info
// Store cache outside web root if possible (e.g., '../cache/') for better security.
// Ensure the target directory is writable by the web server process.
define('BINANCE_EXCHANGE_INFO_CACHE_FILE', __DIR__ . '/../cache/binance_exchange_info.json');
define('BINANCE_EXCHANGE_INFO_CACHE_DURATION', 3600); // Cache duration in seconds (1 hour)

// --- Core API Request Helper ---

/**
 * Private helper function to make requests to the Binance API.
 * Handles common cURL setup, execution, error checking, and JSON decoding.
 *
 * @param string $endpoint The API endpoint path (e.g., /api/v3/ticker/price).
 * @param array $params Optional query parameters as an associative array.
 * @param string $method The HTTP method (GET, POST, etc.) - defaults to GET.
 * @return array|null Decoded JSON response as an associative array, or null on certain errors.
 * @throws Exception If cURL fails critically, JSON decoding fails, or Binance returns an error structure.
 */
function _makeBinanceApiRequest(string $endpoint, array $params = [], string $method = 'GET') // Added $method param
{
    $url = BINANCE_API_BASE_URL . $endpoint;

    $ch = curl_init();

    // Configure based on method
    if (strtoupper($method) === 'GET' && !empty($params)) {
        $url .= '?' . http_build_query($params);
    } elseif (strtoupper($method) === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params)); // Send as form-encoded
        // If API expected JSON POST body:
        // curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
        // curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    } // Add other methods (PUT, DELETE) if needed

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, BINANCE_API_TIMEOUT);
    curl_setopt($ch, CURLOPT_TIMEOUT, BINANCE_API_TIMEOUT);
    curl_setopt($ch, CURLOPT_USERAGENT, 'CryptoPaperTrader/1.0 (PHP cURL)');
    // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); // Usually enabled by default
    // curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErrorNum = curl_errno($ch);
    $curlError = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curlErrorNum > 0) {
        throw new Exception("cURL Error calling Binance API ($endpoint): #" . $curlErrorNum . " - " . $curlError);
    }

    // Handle non-2xx/3xx HTTP status codes
    // Allow 4xx errors through for specific handling, but throw for 5xx or unexpected codes.
    if ($httpCode >= 400) {
         // Try to decode response anyway to get potential error message from Binance
         $errorData = json_decode($response, true);
         $errorMessage = $errorData['msg'] ?? "HTTP Status Code: $httpCode";
         // Throw specific exception for common errors if needed, e.g., 404 for invalid symbol
         // if ($httpCode === 404 && isset($errorData['code']) && $errorData['code'] === -1121) {
         //     throw new InvalidArgumentException("Binance API Error ($endpoint): Invalid Symbol - {$errorMessage}");
         // }
         throw new Exception("Binance API Error ($endpoint): " . $errorMessage . " (HTTP $httpCode)");
     }


    // Handle empty response specifically if needed (though 2xx usually have content)
    if ($httpCode >= 200 && $httpCode < 300 && ($response === false || $response === '')) {
        // For some successful calls (like 204 No Content), an empty response is valid
        // If expecting content, this might be an issue.
        // For now, let's return null or empty array depending on expected output.
         return []; // Assume empty array is safer default for list endpoints
        // throw new Exception("Empty response received from Binance API ($endpoint) despite success code $httpCode.");
    }

    // Decode JSON response
    $data = json_decode($response, true);

    // Check for JSON decoding errors
    if (json_last_error() !== JSON_ERROR_NONE) {
        // Include part of the response for context if possible
        $preview = substr($response, 0, 100);
        throw new Exception("Failed to decode JSON response from Binance API ($endpoint): " . json_last_error_msg() . ". Response start: " . $preview);
    }

    // Check for Binance specific error format within the JSON payload (if httpCode wasn't >= 400)
    // This might catch errors Binance returns with a 200 OK status sometimes (though less common now)
    if (isset($data['code']) && isset($data['msg']) && $data['code'] < 0) { // Check for negative error codes
        throw new Exception("Binance API Logic Error ($endpoint): Code {$data['code']} - {$data['msg']}");
    }

    return $data;
}

// --- Public API Functions ---

/**
 * Fetches the latest price for a single trading pair.
 * Uses /api/v3/ticker/price?symbol=...
 *
 * @param string $trading_pair The trading pair symbol (e.g., BTCUSDT).
 * @return string The price as a string.
 * @throws InvalidArgumentException If the symbol format is invalid.
 * @throws Exception If the API request fails or price is not found.
 */
function fetchSingleCryptoPrice(string $trading_pair): string
{
    $trading_pair = strtoupper(trim($trading_pair));
    if (empty($trading_pair) || !preg_match('/^[A-Z0-9]{4,}$/', $trading_pair)) {
        throw new InvalidArgumentException("Invalid trading pair format provided: $trading_pair");
    }

    $endpoint = '/api/v3/ticker/price';
    $params = ['symbol' => $trading_pair];

    try {
        $data = _makeBinanceApiRequest($endpoint, $params);

        if (!isset($data['price']) || !isset($data['symbol'])) {
            throw new Exception("Price or symbol key not found in response for {$trading_pair}. Response: " . json_encode($data));
        }
        // Optional: Verify returned symbol matches requested symbol
        // if ($data['symbol'] !== $trading_pair) { ... }

        return (string)$data['price'];

    } catch (Exception $e) {
        // Re-throw exception to be handled by the caller, log it here too
        error_log("Error in fetchSingleCryptoPrice for $trading_pair: " . $e->getMessage());
        throw $e;
    }
}

/**
 * Fetches the latest prices for multiple specific trading pairs efficiently.
 * Uses /api/v3/ticker/price?symbols=[...]
 *
 * @param array $trading_pairs An array of trading pair symbols (e.g., ['BTCUSDT', 'ETHUSDT']).
 * @return array An associative array mapping symbol to price (e.g., ['BTCUSDT' => '65000.50', ...]). Returns empty array if input is empty or invalid.
 * @throws Exception If the API request fails.
 */
function fetchMultipleCryptoPrices(array $trading_pairs): array
{
    if (empty($trading_pairs)) return [];

    $sanitized_pairs = array_values(array_unique(array_map('strtoupper', array_map('trim', $trading_pairs))));
    $sanitized_pairs = array_filter($sanitized_pairs, fn($symbol) => !empty($symbol) && preg_match('/^[A-Z0-9]{4,}$/', $symbol));
    if (empty($sanitized_pairs)) return [];

    $endpoint = '/api/v3/ticker/price';
    // Binance expects a URL-encoded JSON array string for the 'symbols' parameter
    $params = ['symbols' => json_encode($sanitized_pairs)]; // No need for urlencode, http_build_query handles it

    try {
        $data = _makeBinanceApiRequest($endpoint, $params); // This returns an array of price objects

        $prices = [];
        if (is_array($data)) {
            foreach ($data as $item) {
                if (isset($item['symbol']) && isset($item['price'])) {
                    $prices[$item['symbol']] = (string)$item['price'];
                }
            }
        } else {
             throw new Exception("Unexpected data format received for multiple prices. Expected array, got: " . gettype($data));
        }
        return $prices;

    } catch (Exception $e) {
        error_log("Error in fetchMultipleCryptoPrices: " . $e->getMessage());
        throw $e;
    }
}

/**
 * Fetches 24hr ticker price change statistics for all symbols.
 * Uses the /api/v3/ticker/24hr endpoint.
 *
 * @return array An array of ticker statistics objects.
 * @throws Exception If the API request fails or response is not an array.
 */
function fetch24hrTickerData(): array
{
    $endpoint = '/api/v3/ticker/24hr';
    try {
        // Make request with no parameters to get all symbols
        $data = _makeBinanceApiRequest($endpoint); // Default method is GET
        if (!is_array($data)) {
             throw new Exception("Unexpected non-array response from /ticker/24hr endpoint.");
        }
        return $data;
    } catch (Exception $e) {
        error_log("Error in fetch24hrTickerData: " . $e->getMessage());
        throw $e; // Re-throw exception
    }
}


/**
 * Fetches exchange information (list of symbols, rules, etc.) from Binance.
 * Implements simple file-based caching.
 * Uses /api/v3/exchangeInfo
 *
 * @return array The 'symbols' array from the exchange info response. Returns empty array on cache failure if API also fails.
 * @throws Exception If the API request fails critically and no usable cache exists.
 */
function fetchExchangeInfo(): array
{
    $cache_file = BINANCE_EXCHANGE_INFO_CACHE_FILE;
    $cache_duration = BINANCE_EXCHANGE_INFO_CACHE_DURATION;
    $cache_dir = dirname($cache_file);

    // --- Check Cache ---
    if (file_exists($cache_file) && is_readable($cache_file) && (time() - filemtime($cache_file)) < $cache_duration) {
        $cached_data_json = file_get_contents($cache_file);
        if ($cached_data_json !== false) {
            $cached_data = json_decode($cached_data_json, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($cached_data) && isset($cached_data['symbols']) && is_array($cached_data['symbols'])) {
                error_log("Using cached Binance exchange info."); // Log cache usage
                return $cached_data['symbols']; // Return only the symbols part
            } else {
                 error_log("Warning: Invalid data found in Binance exchange info cache: $cache_file");
                 @unlink($cache_file); // Attempt to delete corrupt cache
            }
        } else {
            error_log("Warning: Could not read Binance exchange info cache file: $cache_file");
        }
    }

    // --- Fetch Fresh Data ---
    error_log("Fetching fresh Binance exchange info."); // Log fresh fetch
    $endpoint = '/api/v3/exchangeInfo';
    try {
        $data = _makeBinanceApiRequest($endpoint);

        if (!isset($data['symbols']) || !is_array($data['symbols'])) {
            throw new Exception("Symbols key not found or not an array in exchange info response.");
        }

        // --- Try to Update Cache ---
        // Ensure cache directory exists and is writable
        if (!is_dir($cache_dir)) {
            if (!@mkdir($cache_dir, 0755, true)) { // Create recursively, suppress errors on failure
                 error_log("Warning: Could not create cache directory: $cache_dir");
            }
        }
        if (is_dir($cache_dir) && is_writable($cache_dir)) {
            if (file_put_contents($cache_file, json_encode($data), LOCK_EX) === false) { // Write ENTIRE response to cache
                error_log("Warning: Could not write to Binance exchange info cache file: $cache_file");
            } else {
                 error_log("Successfully updated Binance exchange info cache.");
            }
         } else {
             error_log("Warning: Cache directory not writable or does not exist: $cache_dir");
         }

        // Return only the symbols array from fresh data
        return $data['symbols'];

    } catch (Exception $e) {
        error_log("Error in fetchExchangeInfo: " . $e->getMessage());
        // --- Fallback: Try to return stale cache if API failed ---
        if (file_exists($cache_file) && is_readable($cache_file)) {
             $cached_data_json = file_get_contents($cache_file);
             if ($cached_data_json !== false) {
                 $cached_data = json_decode($cached_data_json, true);
                 if (json_last_error() === JSON_ERROR_NONE && is_array($cached_data) && isset($cached_data['symbols']) && is_array($cached_data['symbols'])) {
                     error_log("Warning: Returning stale Binance exchange info due to API fetch failure.");
                     return $cached_data['symbols'];
                 }
             }
        }
        // If API failed AND cache is bad/unavailable, re-throw or return empty
        // throw $e; // Option 1: Re-throw the exception
        return []; // Option 2: Return empty array gracefully
    }
}
