<?php

// Inside config.php
ini_set('display_errors', 0); // Turn off display
ini_set('log_errors', 1);    // Ensure logging is on
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING); // Optionally hide notices/warnings too, but fixing them is better
/**
 * includes/config.php
 *
 * Main configuration file for the Crypto Paper Trader application.
 * Contains database credentials and other application-wide settings.
 *
 * IMPORTANT SECURITY NOTE:
 * This file contains sensitive information (database credentials).
 * It's strongly recommended to place this file (or just the sensitive parts)
 * OUTSIDE of your web server's document root for security reasons,
 * if your hosting environment allows it.
 * If kept within the web root (like in this 'includes' directory),
 * ensure your web server is configured (e.g., via .htaccess on Apache)
 * to DENY direct web access to the 'includes' directory and its contents.
 */

// --- Database Configuration ---
// Replace with your actual database connection details.
define('DB_HOST', 'localhost');         // Database host (e.g., 'localhost' or IP address)
define('DB_NAME', 'cryptotrader_db');   // Your database name
define('DB_USER', 'root');              // Your database username
define('DB_PASS', '');                  // Your database password - **CHANGE THIS**
define('DB_CHARSET', 'utf8mb4');        // Database character set (utf8mb4 is recommended for full Unicode support)


// --- Application Settings ---
define('DEFAULT_STARTING_CASH', 100000.00); // Initial virtual cash for new users (e.g., $100,000.00)
define('SITE_NAME', 'Crypto Paper Trader'); // Your website's name (optional, for titles etc.)


// --- API Settings ---
// We are using public Binance endpoints, so no API keys are strictly required here *for those*.
// If you were to use private/signed Binance endpoints (e.g., for actual order placement
// on a real exchange API, or accessing account data), you would define your keys here:
// define('BINANCE_API_KEY', 'YOUR_BINANCE_API_KEY');
// define('BINANCE_SECRET_KEY', 'YOUR_BINANCE_SECRET_KEY');


// --- Error Reporting ---
// Set error reporting level.
// For Development: Display all errors to help with debugging.
error_reporting(E_ALL);
ini_set('display_errors', 1); // Show errors on screen
// For Production: Log errors but DO NOT display them to users.
// error_reporting(E_ALL);
// ini_set('display_errors', 0); // Hide errors from screen
// ini_set('log_errors', 1); // Log errors to the server's error log
// ini_set('error_log', '/path/to/your/php-error.log'); // Optional: Specify log file


// --- Timezone ---
// Set the default timezone for date/time functions.
// Using UTC is often recommended for server-side consistency.
// Find your timezone here: https://www.php.net/manual/en/timezones.php
define('DEFAULT_TIMEZONE', 'UTC');
date_default_timezone_set(DEFAULT_TIMEZONE);


// --- Session Settings (Can also be here, but often handled in session.php) ---
// Example: Session name (change from default PHPSESSID for slight obscurity)
// ini_set('session.name', 'MYAPPSESSID');


// --- Other Constants ---
// Add any other application-wide constants you might need here.
// define('ITEMS_PER_PAGE', 20);


